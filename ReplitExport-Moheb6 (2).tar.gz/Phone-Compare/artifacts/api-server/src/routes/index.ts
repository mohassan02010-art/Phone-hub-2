import { Router, type IRouter } from "express";
import healthRouter from "./health";
import phonesRouter from "./phones";
import brandsRouter from "./brands";
import analyticsRouter from "./analytics";

const router: IRouter = Router();

router.use(healthRouter);
router.use(phonesRouter);
router.use(brandsRouter);
router.use(analyticsRouter);

export default router;
