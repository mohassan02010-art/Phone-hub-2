import { Router, type IRouter } from "express";
import { db, phonesTable } from "@workspace/db";
import { sql, desc } from "drizzle-orm";

const router: IRouter = Router();

router.get("/brands", async (_req, res): Promise<void> => {
  const brands = await db
    .select({
      name: phonesTable.brand,
      count: sql<number>`cast(count(*) as int)`,
    })
    .from(phonesTable)
    .groupBy(phonesTable.brand)
    .orderBy(desc(sql`count(*)`));

  res.json(
    brands.map((b) => ({
      name: b.name,
      count: b.count,
      logoUrl: null,
    })),
  );
});

export default router;
