import React from 'react';
import { cn } from '@/lib/utils';

/* ── Base shimmer block ──────────────────────────────────────────────── */
export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('skeleton rounded-lg', className)} />;
}

/* ── Full phone card skeleton ─────────────────────────────────────────── */
export function SkeletonCard({ delay = 0 }: { delay?: number }) {
  return (
    <div
      className="bg-card border border-border rounded-2xl overflow-hidden flex flex-col"
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* Image area */}
      <div className="h-48 skeleton rounded-none" />

      {/* Content */}
      <div className="p-5 flex flex-col gap-3 flex-grow">
        <Skeleton className="h-3 w-16" />
        <Skeleton className="h-5 w-3/4" />
        <Skeleton className="h-4 w-1/2" />

        <div className="grid grid-cols-2 gap-2 mt-2">
          <Skeleton className="h-3 w-full" />
          <Skeleton className="h-3 w-full" />
          <Skeleton className="h-3 w-full" />
          <Skeleton className="h-3 w-full" />
        </div>

        <div className="pt-3 border-t border-white/[0.06] flex items-center justify-between mt-auto">
          <Skeleton className="h-3 w-10" />
          <Skeleton className="h-4 w-14" />
        </div>
      </div>
    </div>
  );
}

/* ── Horizontal compact skeleton ──────────────────────────────────────── */
export function SkeletonRow({ delay = 0 }: { delay?: number }) {
  return (
    <div
      className="flex items-center gap-4 p-4 rounded-xl bg-card border border-border"
      style={{ animationDelay: `${delay}ms` }}
    >
      <Skeleton className="w-8 h-8 rounded-full flex-shrink-0" />
      <Skeleton className="w-10 h-12 rounded-lg flex-shrink-0" />
      <div className="flex-1 space-y-2">
        <Skeleton className="h-3 w-20" />
        <Skeleton className="h-4 w-3/5" />
        <Skeleton className="h-1.5 w-full rounded-full" />
      </div>
      <div className="text-right space-y-1.5 flex-shrink-0">
        <Skeleton className="h-4 w-14" />
        <Skeleton className="h-3 w-8 ml-auto" />
      </div>
    </div>
  );
}

/* ── Grid of card skeletons ───────────────────────────────────────────── */
export function SkeletonGrid({ count = 8, cols = 4 }: { count?: number; cols?: number }) {
  const gridClass = {
    2: 'grid-cols-2',
    3: 'grid-cols-2 sm:grid-cols-3',
    4: 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4',
    6: 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-6',
  }[cols] ?? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-4';

  return (
    <div className={`grid ${gridClass} gap-5`}>
      {Array.from({ length: count }).map((_, i) => (
        <SkeletonCard key={i} delay={i * 40} />
      ))}
    </div>
  );
}

/* ── Phone detail hero skeleton ───────────────────────────────────────── */
export function SkeletonDetailHero() {
  return (
    <div className="border-b border-border bg-card/20">
      {/* Breadcrumb */}
      <div className="container mx-auto px-4 py-3 flex items-center gap-2">
        <Skeleton className="h-4 w-36" />
      </div>

      {/* Hero */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-5">
            <Skeleton className="h-6 w-24 rounded-full" />
            <Skeleton className="h-16 w-3/4" />
            <div className="flex items-center gap-6 pt-2">
              <div className="space-y-2">
                <Skeleton className="h-10 w-28" />
                <Skeleton className="h-3 w-20" />
              </div>
              <Skeleton className="h-16 w-28 rounded-xl" />
            </div>
            <div className="flex gap-2 flex-wrap pt-2">
              {[60, 40, 90, 50, 70].map((w, i) => (
                <Skeleton key={i} className={`h-7 rounded-lg`} style={{ width: w }} />
              ))}
            </div>
            <div className="flex gap-3 pt-2">
              <Skeleton className="h-12 w-40 rounded-xl" />
              <Skeleton className="h-12 w-32 rounded-xl" />
            </div>
          </div>
          <Skeleton className="h-[400px] rounded-3xl" />
        </div>
      </div>

      {/* Key specs */}
      <div className="container mx-auto px-4 pb-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="bg-card border border-border rounded-2xl p-5 space-y-3">
              <Skeleton className="h-8 w-8 rounded-lg" />
              <Skeleton className="h-7 w-24" />
              <Skeleton className="h-3 w-32" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
