import { Router, type IRouter } from "express";
import { db, phonesTable } from "@workspace/db";
import { sql, desc, asc, isNotNull } from "drizzle-orm";

const router: IRouter = Router();

router.get("/analytics/stats", async (_req, res): Promise<void> => {
  const [stats] = await db
    .select({
      totalPhones: sql<number>`cast(count(*) as int)`,
      totalBrands: sql<number>`cast(count(distinct ${phonesTable.brand}) as int)`,
      avgPriceUsd: sql<number>`round(avg(${phonesTable.priceUsd})::numeric, 0)`,
      phonesWithNfc: sql<number>`cast(sum(case when ${phonesTable.hasNfc} then 1 else 0 end) as int)`,
      phonesWith5g: sql<number>`cast(sum(case when ${phonesTable.has5g} then 1 else 0 end) as int)`,
      latestYear: sql<number>`max(${phonesTable.launchYear})`,
    })
    .from(phonesTable);

  res.json({
    totalPhones: stats?.totalPhones ?? 0,
    totalBrands: stats?.totalBrands ?? 0,
    avgPriceUsd: stats?.avgPriceUsd ?? 0,
    phonesWithNfc: stats?.phonesWithNfc ?? 0,
    phonesWith5g: stats?.phonesWith5g ?? 0,
    latestYear: stats?.latestYear ?? 2024,
  });
});

router.get("/analytics/price-distribution", async (_req, res): Promise<void> => {
  const distribution = await db
    .select({
      segment: sql<string>`
        case
          when ${phonesTable.priceUsd} < 200 then 'Budget (<$200)'
          when ${phonesTable.priceUsd} < 400 then 'Mid-Range ($200-$399)'
          when ${phonesTable.priceUsd} < 700 then 'Upper Mid ($400-$699)'
          when ${phonesTable.priceUsd} < 1000 then 'Premium ($700-$999)'
          when ${phonesTable.priceUsd} >= 1000 then 'Ultra Premium ($1000+)'
          else 'Unknown'
        end
      `,
      count: sql<number>`cast(count(*) as int)`,
      avgPrice: sql<number>`round(avg(${phonesTable.priceUsd})::numeric, 0)`,
    })
    .from(phonesTable)
    .where(isNotNull(phonesTable.priceUsd))
    .groupBy(
      sql`
        case
          when ${phonesTable.priceUsd} < 200 then 'Budget (<$200)'
          when ${phonesTable.priceUsd} < 400 then 'Mid-Range ($200-$399)'
          when ${phonesTable.priceUsd} < 700 then 'Upper Mid ($400-$699)'
          when ${phonesTable.priceUsd} < 1000 then 'Premium ($700-$999)'
          when ${phonesTable.priceUsd} >= 1000 then 'Ultra Premium ($1000+)'
          else 'Unknown'
        end
      `,
    )
    .orderBy(sql`min(${phonesTable.priceUsd})`);

  res.json(distribution);
});

router.get("/analytics/brands-by-count", async (_req, res): Promise<void> => {
  const brands = await db
    .select({
      brand: phonesTable.brand,
      count: sql<number>`cast(count(*) as int)`,
    })
    .from(phonesTable)
    .groupBy(phonesTable.brand)
    .orderBy(desc(sql`count(*)`))
    .limit(15);

  res.json(brands);
});

router.get("/analytics/yearly-releases", async (_req, res): Promise<void> => {
  const yearly = await db
    .select({
      year: phonesTable.launchYear,
      count: sql<number>`cast(count(*) as int)`,
    })
    .from(phonesTable)
    .groupBy(phonesTable.launchYear)
    .orderBy(asc(phonesTable.launchYear));

  res.json(yearly);
});

export default router;
