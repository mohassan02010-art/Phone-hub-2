import { Router, type IRouter } from "express";
import { db, phonesTable } from "@workspace/db";
import { eq, ilike, and, gte, lte, sql, desc, asc, inArray, or } from "drizzle-orm";

const router: IRouter = Router();

router.get("/phones/featured", async (req, res): Promise<void> => {
  const limit = Math.min(parseInt(String(req.query.limit ?? "12"), 10), 50);

  const phones = await db
    .select()
    .from(phonesTable)
    .where(gte(phonesTable.rating, 4.0))
    .orderBy(desc(phonesTable.rating), desc(phonesTable.launchYear))
    .limit(limit);

  res.json(phones.map(toPhoneResponse));
});

router.get("/phones/compare", async (req, res): Promise<void> => {
  const idsParam = String(req.query.ids ?? "");
  if (!idsParam) {
    res.status(400).json({ error: "ids parameter is required" });
    return;
  }

  const ids = idsParam
    .split(",")
    .map((s) => parseInt(s.trim(), 10))
    .filter((n) => !isNaN(n));

  if (ids.length < 2 || ids.length > 4) {
    res.status(400).json({ error: "Provide 2-4 phone IDs to compare" });
    return;
  }

  const phones = await db
    .select()
    .from(phonesTable)
    .where(inArray(phonesTable.id, ids));

  res.json(phones.map(toPhoneDetailResponse));
});

router.get("/phones/:id/similar", async (req, res): Promise<void> => {
  const id = parseInt(String(req.params.id), 10);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid phone ID" }); return; }
  const limit = Math.min(12, parseInt(String(req.query.limit ?? "6"), 10));

  const [phone] = await db.select({ brand: phonesTable.brand, priceUsd: phonesTable.priceUsd })
    .from(phonesTable).where(eq(phonesTable.id, id));

  if (!phone) { res.status(404).json({ error: "Phone not found" }); return; }

  const similar = await db.select()
    .from(phonesTable)
    .where(and(eq(phonesTable.brand, phone.brand), sql`${phonesTable.id} != ${id}`))
    .orderBy(desc(phonesTable.launchYear), desc(phonesTable.rating))
    .limit(limit);

  res.json(similar.map(toPhoneResponse));
});

router.get("/phones/:id", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid phone ID" });
    return;
  }

  const [phone] = await db
    .select()
    .from(phonesTable)
    .where(eq(phonesTable.id, id));

  if (!phone) {
    res.status(404).json({ error: "Phone not found" });
    return;
  }

  res.json(toPhoneDetailResponse(phone));
});

router.get("/phones", async (req, res): Promise<void> => {
  const {
    search,
    brand,
    yearFrom,
    yearTo,
    minPrice,
    maxPrice,
    has5g,
    hasNfc,
    minRam,
    maxRam,
    minStorage,
    maxStorage,
    minBattery,
    maxBattery,
    minCamera,
    maxCamera,
    minDisplay,
    maxDisplay,
    sort,
    page: pageQ,
    limit: limitQ,
  } = req.query;

  const page = Math.max(1, parseInt(String(pageQ ?? "1"), 10));
  const limit = Math.min(50, Math.max(1, parseInt(String(limitQ ?? "20"), 10)));
  const offset = (page - 1) * limit;

  const conditions = [];

  if (search && typeof search === "string" && search.trim()) {
    const q = `%${search.trim()}%`;
    conditions.push(
      or(
        ilike(phonesTable.name, q),
        ilike(phonesTable.brand, q),
        ilike(phonesTable.model, q),
        ilike(phonesTable.processor, q),
      ),
    );
  }

  if (brand && typeof brand === "string") {
    conditions.push(ilike(phonesTable.brand, brand));
  }

  if (yearFrom) {
    conditions.push(gte(phonesTable.launchYear, parseInt(String(yearFrom), 10)));
  }

  if (yearTo) {
    conditions.push(lte(phonesTable.launchYear, parseInt(String(yearTo), 10)));
  }

  if (minPrice) {
    conditions.push(gte(phonesTable.priceUsd, parseFloat(String(minPrice))));
  }

  if (maxPrice) {
    conditions.push(lte(phonesTable.priceUsd, parseFloat(String(maxPrice))));
  }

  if (has5g === "true" || has5g === true) {
    conditions.push(eq(phonesTable.has5g, true));
  }

  if (hasNfc === "true" || hasNfc === true) {
    conditions.push(eq(phonesTable.hasNfc, true));
  }

  if (minRam) conditions.push(gte(phonesTable.ram, parseFloat(String(minRam))));
  if (maxRam) conditions.push(lte(phonesTable.ram, parseFloat(String(maxRam))));

  if (minStorage) conditions.push(gte(phonesTable.storage, parseFloat(String(minStorage))));
  if (maxStorage) conditions.push(lte(phonesTable.storage, parseFloat(String(maxStorage))));

  if (minBattery) conditions.push(gte(phonesTable.batteryMah, parseFloat(String(minBattery))));
  if (maxBattery) conditions.push(lte(phonesTable.batteryMah, parseFloat(String(maxBattery))));

  if (minCamera) conditions.push(gte(phonesTable.mainCameraMp, parseFloat(String(minCamera))));
  if (maxCamera) conditions.push(lte(phonesTable.mainCameraMp, parseFloat(String(maxCamera))));

  if (minDisplay) conditions.push(gte(phonesTable.displaySize, parseFloat(String(minDisplay))));
  if (maxDisplay) conditions.push(lte(phonesTable.displaySize, parseFloat(String(maxDisplay))));

  const where = conditions.length > 0 ? and(...conditions) : undefined;

  let orderBy;
  switch (sort) {
    case "price_asc":
      orderBy = asc(phonesTable.priceUsd);
      break;
    case "price_desc":
      orderBy = desc(phonesTable.priceUsd);
      break;
    case "rating":
      orderBy = desc(phonesTable.rating);
      break;
    case "oldest":
      orderBy = asc(phonesTable.launchYear);
      break;
    case "ram_desc":
      orderBy = desc(phonesTable.ram);
      break;
    case "camera_desc":
      orderBy = desc(phonesTable.mainCameraMp);
      break;
    case "battery_desc":
      orderBy = desc(phonesTable.batteryMah);
      break;
    case "charging_desc":
      orderBy = desc(phonesTable.chargingWatts);
      break;
    case "newest":
    default:
      orderBy = desc(phonesTable.launchYear);
      break;
  }

  const [phones, countResult] = await Promise.all([
    db.select().from(phonesTable).where(where).orderBy(orderBy).limit(limit).offset(offset),
    db
      .select({ count: sql<number>`cast(count(*) as int)` })
      .from(phonesTable)
      .where(where),
  ]);

  const total = countResult[0]?.count ?? 0;

  res.json({
    phones: phones.map(toPhoneResponse),
    total,
    page,
    limit,
  });
});

function toPhoneResponse(p: typeof phonesTable.$inferSelect) {
  return {
    id: p.id,
    name: p.name,
    brand: p.brand,
    model: p.model,
    launchYear: p.launchYear,
    launchDate: p.launchDate,
    imageUrl: p.imageUrl,
    priceUsd: p.priceUsd,
    rating: p.rating,
    has5g: p.has5g,
    hasNfc: p.hasNfc,
    displaySize: p.displaySize,
    displayType: p.displayType,
    displayResolution: p.displayResolution,
    displayRefreshRate: p.displayRefreshRate,
    ram: p.ram,
    storage: p.storage,
    mainCameraMp: p.mainCameraMp,
    frontCameraMp: p.frontCameraMp,
    batteryMah: p.batteryMah,
    processor: p.processor,
    os: p.os,
    weight: p.weight,
  };
}

function toPhoneDetailResponse(p: typeof phonesTable.$inferSelect) {
  return {
    ...toPhoneResponse(p),
    hasWirelessCharging: p.hasWirelessCharging,
    hasHeadphoneJack: p.hasHeadphoneJack,
    displayNits: p.displayNits,
    processorNm: p.processorNm,
    ramOptions: p.ramOptions,
    storageOptions: p.storageOptions,
    ultrawideCameraMp: p.ultrawideCameraMp,
    telephotoMp: p.telephotoMp,
    videoResolution: p.videoResolution,
    chargingWatts: p.chargingWatts,
    thickness: p.thickness,
    colors: p.colors,
    simType: p.simType,
    wifi: p.wifi,
    bluetooth: p.bluetooth,
    usb: p.usb,
  };
}

export default router;
