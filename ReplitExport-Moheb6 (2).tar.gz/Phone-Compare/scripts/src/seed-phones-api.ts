/**
 * seed-phones-api.ts
 *
 * Seeds the phones table using the same technique as the open-source
 * Phone Specs API (github.com/azharimm/phone-specs-api):
 *   • Fetch HTML from GSMArena
 *   • Parse with cheerio
 *   • Map the extracted spec object to our flat DB schema
 *
 * No hosted third-party service is required — this is a self-contained
 * implementation of the same scraping logic the open-source project uses.
 */

import * as cheerio from "cheerio";
import { db, phonesTable } from "@workspace/db";

// ─── Config ──────────────────────────────────────────────────────────────────

const GSM_BASE   = "https://www.gsmarena.com";
const DELAY_MS   = 1500;   // pause between requests (be polite)
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
  "AppleWebKit/537.36 (KHTML, like Gecko) " +
  "Chrome/124.0.0.0 Safari/537.36";

// Spec section headings the Phone Specs API scrapes (in order)
const SPEC_SECTIONS = [
  "Network", "Launch", "Body", "Display", "Platform",
  "Memory", "Main Camera", "Selfie camera", "Sound",
  "Comms", "Features", "Battery", "Misc", "Tests",
];

// ─── Brand + page-count catalogue ────────────────────────────────────────────

const BRANDS: Array<{
  slug: string;
  id: number;
  displayName: string;
  pages: number;
  maxPhones: number;
}> = [
  { slug: "apple-phones",    id: 48,  displayName: "Apple",    pages: 2, maxPhones: 14 },
  { slug: "samsung-phones",  id: 9,   displayName: "Samsung",  pages: 3, maxPhones: 16 },
  { slug: "xiaomi-phones",   id: 80,  displayName: "Xiaomi",   pages: 2, maxPhones: 12 },
  { slug: "google-phones",   id: 107, displayName: "Google",   pages: 2, maxPhones: 10 },
  { slug: "oneplus-phones",  id: 95,  displayName: "OnePlus",  pages: 2, maxPhones: 10 },
  { slug: "oppo-phones",     id: 82,  displayName: "OPPO",     pages: 2, maxPhones: 10 },
  { slug: "huawei-phones",   id: 58,  displayName: "Huawei",   pages: 2, maxPhones: 8  },
  { slug: "motorola-phones", id: 4,   displayName: "Motorola", pages: 2, maxPhones: 10 },
  { slug: "nokia-phones",    id: 1,   displayName: "Nokia",    pages: 2, maxPhones: 8  },
  { slug: "sony-phones",     id: 7,   displayName: "Sony",     pages: 2, maxPhones: 8  },
  { slug: "nothing-phones",  id: 128, displayName: "Nothing",  pages: 1, maxPhones: 10 },
  { slug: "asus-phones",     id: 46,  displayName: "ASUS",     pages: 2, maxPhones: 8  },
  { slug: "honor-phones",    id: 121, displayName: "Honor",    pages: 2, maxPhones: 8  },
  { slug: "infinix-phones",  id: 119, displayName: "Infinix",  pages: 2, maxPhones: 8  },
  { slug: "realme-phones",   id: 118, displayName: "Realme",   pages: 2, maxPhones: 8  },
  { slug: "tecno-phones",    id: 120, displayName: "TECNO",    pages: 2, maxPhones: 6  },
  { slug: "vivo-phones",     id: 98,  displayName: "vivo",     pages: 2, maxPhones: 8  },
  { slug: "zte-phones",      id: 62,  displayName: "ZTE",      pages: 2, maxPhones: 6  },
];

// Skip non-phone devices by name keyword
const NON_PHONE_KEYWORDS = [
  "tab ", " tab", "tablet", "ipad", "watch", " pad", "pad ",
  "earphone", "earbuds", "buds", " band", "trifold", "tri fold",
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function sleep(ms: number) {
  return new Promise<void>((r) => setTimeout(r, ms));
}

async function gsmFetch(url: string): Promise<string> {
  const res = await fetch(url, {
    headers: {
      "User-Agent": UA,
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.5",
    },
    redirect: "follow",
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${url}`);
  return res.text();
}

// ─── Phone listing scraper (mirrors brandController.js) ───────────────────────

interface PhoneListing {
  slug: string;
  phone_name: string;
  image: string;
}

async function fetchBrandPage(
  brandSlug: string,
  brandId: number,
  page: number
): Promise<PhoneListing[]> {
  let url: string;
  if (page === 1) {
    url = `${GSM_BASE}/${brandSlug}-${brandId}.php`;
  } else {
    // e.g. apple-phones-f-48-0-p2.php
    url = `${GSM_BASE}/${brandSlug}-f-${brandId}-0-p${page}.php`;
  }

  const html = await gsmFetch(url);
  const $ = cheerio.load(html);
  const phones: PhoneListing[] = [];

  $(".makers ul li").each((_i, el) => {
    const a    = $(el).children("a");
    const href = a.attr("href") ?? "";
    const slug = href.replace(".php", "");
    const name = a.find("strong span").text().trim() || a.text().trim();
    const img  = a.find("img").attr("src") ?? "";
    if (slug) phones.push({ slug, phone_name: name, image: img });
  });

  return phones;
}

// ─── Phone spec scraper (mirrors specController.js) ───────────────────────────

interface SpecEntry  { key: string; val: string[] }
interface SpecSection { title: string; specs: SpecEntry[] }
interface PhoneSpec {
  brand: string;
  phone_name: string;
  thumbnail: string;
  release_date: string;
  dimension: string;
  os: string;
  storage: string;
  specifications: SpecSection[];
}

async function fetchPhoneSpec(slug: string): Promise<PhoneSpec | null> {
  try {
    const html = await gsmFetch(`${GSM_BASE}/${slug}.php`);
    const $ = cheerio.load(html);

    const fullName = $("h1.specs-phone-name-title").text().trim();
    if (!fullName) return null;

    const thumbnail  = $(".specs-photo-main").children("a").children("img").attr("src") ?? "";
    const releaseDate = $(".icon-launched").next().text().trim();
    const dimension   = $(".icon-mobile2").next().text().trim();
    const osText      = $(".icon-os").next().text().trim();
    const storageText = $(".icon-sd-card-0").next().text().trim();

    // Brand = first word; phone_name = rest (matches specController.js logic)
    const brandWord  = fullName.split(" ")[0];
    const phoneName  = fullName.slice(brandWord.length).trim();

    // Extract spec sections
    const specifications: SpecSection[] = [];
    for (const sectionTitle of SPEC_SECTIONS) {
      // Find the <th> that exactly matches the section title
      let th: cheerio.Cheerio<cheerio.Element> | null = null;
      $("th").each((_i, el) => {
        if ($(el).text().trim() === sectionTitle) th = $(el) as any;
      });
      if (!th) continue;

      const specs: SpecEntry[] = [];
      let prevKey = "";

      (th as cheerio.Cheerio<cheerio.Element>)
        .closest("tbody")
        .children("tr")
        .each((_i, tr) => {
          const key = $(tr).find("td.ttl a").text().trim();
          const val = $(tr).find("td.nfo").text().trim();
          if (!val) return;

          if (key) {
            specs.push({ key, val: [val] });
            prevKey = key;
          } else {
            // Continuation row — append to last key
            const last = specs.find((s) => s.key === prevKey);
            if (last) last.val.push(val);
            else specs.push({ key: "Other", val: [val] });
          }
        });

      if (specs.length) specifications.push({ title: sectionTitle, specs });
    }

    return {
      brand: brandWord,
      phone_name: phoneName || fullName,
      thumbnail,
      release_date: releaseDate,
      dimension,
      os: osText,
      storage: storageText,
      specifications,
    };
  } catch (e) {
    console.error(`  ⚠ spec fetch failed for ${slug}: ${(e as Error).message}`);
    return null;
  }
}

// ─── Spec → DB row mapper ─────────────────────────────────────────────────────

/** Find a spec value by section title + key (case-insensitive partial match) */
function getSpec(specs: SpecSection[], section: string, key: string): string {
  const sec = specs.find((s) => s.title.toLowerCase() === section.toLowerCase());
  if (!sec) return "";
  const entry = sec.specs.find((sp) =>
    sp.key.toLowerCase().includes(key.toLowerCase())
  );
  return entry?.val.join(" ").trim() ?? "";
}

function parseDisplaySize(raw: string): number | null {
  const m = raw.match(/([\d.]+)\s*inch/i);
  return m ? parseFloat(m[1]) : null;
}

function parseResolution(raw: string): string | null {
  const m = raw.match(/(\d+)\s*[x×]\s*(\d+)/i);
  return m ? `${m[1]}x${m[2]}` : null;
}

function parseRefreshRate(raw: string): number | null {
  const m = raw.match(/(\d+)\s*Hz/i);
  return m ? parseInt(m[1], 10) : null;
}

function parseNits(raw: string): number | null {
  const m = raw.match(/(\d+)\s*nits/i);
  return m ? parseInt(m[1], 10) : null;
}

function parseDisplayType(raw: string): string {
  return raw.split(",")[0].split("\n")[0].trim().substring(0, 60);
}

function parseProcessorNm(raw: string): number | null {
  const m = raw.match(/\(\s*(\d+)\s*nm\s*\)/i);
  return m ? parseInt(m[1], 10) : null;
}

function parseRam(raw: string): number | null {
  const matches = [...raw.matchAll(/(\d+)\s*GB\s*RAM/gi)];
  if (!matches.length) return null;
  return Math.max(...matches.map((m) => parseInt(m[1], 10)));
}

function parseStorage(raw: string): number | null {
  const m = raw.match(/(\d+)\s*GB(?!\s*RAM)/i);
  return m ? parseInt(m[1], 10) : null;
}

function parseRamOptions(raw: string): string | null {
  const vals = [...new Set([...raw.matchAll(/(\d+)\s*GB\s*RAM/gi)].map((m) => m[1]))];
  return vals.length ? vals.map((v) => `${v}GB`).join("/") : null;
}

function parseStorageOptions(storageField: string, internalSpec: string): string | null {
  const m = storageField.match(/([\d/]+\s*GB)/i);
  if (m) return m[1].replace(/\s/g, "");
  const vals = [...new Set([...internalSpec.matchAll(/(\d+)\s*GB(?!\s*RAM)/gi)].map((m) => m[1]))];
  return vals.length ? vals.join("/") + "GB" : null;
}

function parseCameraMp(line: string): number | null {
  const m = line.match(/^(\d+(?:\.\d+)?)\s*MP/i);
  return m ? parseFloat(m[1]) : null;
}

function parseCameras(raw: string) {
  let main: number | null = null, ultrawide: number | null = null, telephoto: number | null = null;
  for (const line of raw.split("\n").map((l) => l.trim()).filter(Boolean)) {
    const mp  = parseCameraMp(line);
    if (!mp) continue;
    const low = line.toLowerCase();
    if ((low.includes("ultrawide") || low.includes("ultra wide")) && !ultrawide) ultrawide = mp;
    else if ((low.includes("telephoto") || low.includes("periscope") || low.includes("zoom")) && !telephoto) telephoto = mp;
    else if (!main) main = mp;
  }
  return { main, ultrawide, telephoto };
}

function parseBatteryMah(raw: string): number | null {
  const m = raw.match(/(\d{3,5})\s*mAh/i);
  return m ? parseInt(m[1], 10) : null;
}

function parseChargingWatts(raw: string): number | null {
  const matches = [...raw.matchAll(/(\d+)\s*W/gi)];
  if (!matches.length) return null;
  return Math.max(...matches.map((m) => parseInt(m[1], 10)));
}

function parseWeight(raw: string): number | null {
  const m = raw.match(/([\d.]+)\s*g(?:\s|\(|$)/i);
  return m ? parseFloat(m[1]) : null;
}

function parseThickness(dimension: string, dimensionsSpec: string): number | null {
  const m = dimension.match(/([\d.]+)\s*mm\s*thickness/i);
  if (m) return parseFloat(m[1]);
  const d = dimensionsSpec.match(/[\d.]+ x [\d.]+ x ([\d.]+)\s*mm/i);
  return d ? parseFloat(d[1]) : null;
}

function parsePriceUsd(raw: string): number | null {
  const m = raw.match(/\$\s*([\d,]+(?:\.\d+)?)/);
  return m ? parseFloat(m[1].replace(",", "")) : null;
}

function parseWifi(raw: string): string {
  if (/Wi-Fi 7/i.test(raw))  return "Wi-Fi 7";
  if (/Wi-Fi 6E/i.test(raw)) return "Wi-Fi 6E";
  if (/Wi-Fi 6/i.test(raw))  return "Wi-Fi 6";
  if (/Wi-Fi 5|802\.11 a\/b\/g\/n\/ac/i.test(raw)) return "Wi-Fi 5";
  return raw.split(",")[0].trim().substring(0, 20);
}

function parseLaunchYear(releaseDate: string, announced: string): number {
  const m = releaseDate.match(/\b(20\d\d)\b/) ?? announced.match(/\b(20\d\d)\b/);
  return m ? parseInt(m[1], 10) : new Date().getFullYear();
}

function estimateRating(brand: string, priceUsd: number | null): number {
  const BASE: Record<string, number> = {
    Apple: 4.6, Samsung: 4.4, Google: 4.5, OnePlus: 4.4, Sony: 4.3,
    Nothing: 4.3, ASUS: 4.3, Huawei: 4.2, Xiaomi: 4.2, OPPO: 4.1,
    Motorola: 4.1, Realme: 4.0, vivo: 4.0, Honor: 4.0, Nokia: 3.9,
    Infinix: 3.8, TECNO: 3.8, ZTE: 3.7,
  };
  const base      = BASE[brand] ?? 4.0;
  const priceBump = priceUsd && priceUsd > 800 ? 0.2 : priceUsd && priceUsd > 400 ? 0.1 : 0;
  return Math.round(Math.min(4.9, base + priceBump) * 10) / 10;
}

function mapSpecToRow(
  spec: PhoneSpec,
  displayName: string
): typeof phonesTable.$inferInsert | null {
  const s = spec.specifications;
  if (!s.length) return null;

  const relDate   = spec.release_date ?? "";
  const announced = getSpec(s, "Launch", "Announced");
  const year      = parseLaunchYear(relDate, announced);
  if (year < 2020) return null;

  const name   = spec.phone_name?.trim() || "Unknown";
  const brand  = displayName;
  const model  = name.replace(new RegExp(`^${brand}\\s*`, "i"), "").trim() || name;
  const imageUrl = spec.thumbnail ?? "";

  // Display
  const dtRaw  = getSpec(s, "Display", "Type");
  const dszRaw = getSpec(s, "Display", "Size");
  const dresRaw= getSpec(s, "Display", "Resolution");

  // Platform
  const chipRaw = getSpec(s, "Platform", "Chipset");
  const osRaw   = getSpec(s, "Platform", "OS") || spec.os;

  // Memory
  const intRaw  = getSpec(s, "Memory", "Internal");

  // Cameras
  const camKey  = (["Quad","Triple","Dual","Single"] as const)
    .find((k) => getSpec(s, "Main Camera", k)) ?? "Single";
  const camRaw  = getSpec(s, "Main Camera", camKey);
  const videoRaw= getSpec(s, "Main Camera", "Video");
  const selfKey = (["Dual","Single"] as const)
    .find((k) => getSpec(s, "Selfie camera", k)) ?? "Single";
  const selfRaw = getSpec(s, "Selfie camera", selfKey);

  // Battery
  const batRaw  = getSpec(s, "Battery", "Type");
  const chgRaw  = getSpec(s, "Battery", "Charging");

  // Comms
  const techRaw = getSpec(s, "Network", "Technology");
  const nfcRaw  = getSpec(s, "Comms", "NFC");
  const jackRaw = getSpec(s, "Sound", "3.5mm jack");
  const wlanRaw = getSpec(s, "Comms", "WLAN");
  const btRaw   = getSpec(s, "Comms", "Bluetooth");
  const usbRaw  = getSpec(s, "Comms", "USB");

  // Misc
  const colorsRaw = getSpec(s, "Misc", "Colors");
  const priceRaw  = getSpec(s, "Misc", "Price");
  const weightRaw = getSpec(s, "Body", "Weight");
  const dimRaw    = getSpec(s, "Body", "Dimensions");
  const simRaw    = getSpec(s, "Body", "SIM");

  const priceUsd    = parsePriceUsd(priceRaw);
  const { main: mainCameraMp, ultrawide: ultrawideCameraMp, telephoto: telephotoMp } =
    parseCameras(camRaw);

  return {
    name,
    brand,
    model,
    launchYear: year,
    launchDate: announced || null,
    imageUrl,
    priceUsd,
    rating: estimateRating(brand, priceUsd),

    has5g: /5G/i.test(techRaw),
    hasNfc: /yes/i.test(nfcRaw),
    hasWirelessCharging: /wireless|qi/i.test(chgRaw),
    hasHeadphoneJack: /yes/i.test(jackRaw),

    displaySize: parseDisplaySize(dszRaw),
    displayType: dtRaw ? parseDisplayType(dtRaw) : null,
    displayResolution: dresRaw ? parseResolution(dresRaw) : null,
    displayRefreshRate: parseRefreshRate(dtRaw) ?? 60,
    displayNits: parseNits(dtRaw),

    processor: chipRaw.split("\n")[0].split(" - ")[0].trim().substring(0, 80) || null,
    processorNm: chipRaw ? parseProcessorNm(chipRaw) : null,
    ram: parseRam(intRaw),
    storage: parseStorage(intRaw),
    ramOptions: parseRamOptions(intRaw),
    storageOptions: parseStorageOptions(spec.storage ?? "", intRaw),

    mainCameraMp,
    ultrawideCameraMp,
    telephotoMp,
    frontCameraMp: parseCameraMp(selfRaw),
    videoResolution: videoRaw.split(",")[0].trim().substring(0, 30) || null,

    batteryMah: parseBatteryMah(batRaw),
    chargingWatts: parseChargingWatts(chgRaw),

    os: osRaw.split("\n")[0].trim().substring(0, 80) || null,
    weight: parseWeight(weightRaw),
    thickness: parseThickness(spec.dimension ?? "", dimRaw),
    colors: colorsRaw.substring(0, 100) || null,
    simType: simRaw.split("\n")[0].split("·").pop()?.trim().substring(0, 30) || null,

    wifi: wlanRaw ? parseWifi(wlanRaw) : null,
    bluetooth: btRaw ? btRaw.match(/^([\d.]+)/)?.[1] ?? null : null,
    usb: usbRaw.split(",")[0].trim().substring(0, 30) || null,
  };
}

// ─── Main ─────────────────────────────────────────────────────────────────────

async function main() {
  console.log("🚀 Seeding phones via GSMArena scrape (Phone Specs API technique)...\n");

  const rows: (typeof phonesTable.$inferInsert)[] = [];
  const seenSlugs = new Set<string>();

  for (const brand of BRANDS) {
    console.log(`📱 ${brand.displayName}`);

    // Collect phone slugs from brand listing pages
    const listings: PhoneListing[] = [];
    for (let page = 1; page <= brand.pages; page++) {
      try {
        const pageListings = await fetchBrandPage(brand.slug, brand.id, page);
        listings.push(...pageListings);
        console.log(`   Page ${page}: ${pageListings.length} phones found`);
      } catch (e) {
        console.error(`   ⚠ Brand page ${page} failed: ${(e as Error).message}`);
        break;
      }
      await sleep(DELAY_MS);
    }

    // Filter non-phones (tablets, watches, etc.)
    const phones = listings.filter((l) => {
      const low = l.phone_name.toLowerCase();
      return !NON_PHONE_KEYWORDS.some((kw) => low.includes(kw));
    });

    // Fetch specs for up to maxPhones devices from 2020+
    let fetched = 0;
    for (const listing of phones) {
      if (fetched >= brand.maxPhones) break;
      if (seenSlugs.has(listing.slug)) continue;

      const spec = await fetchPhoneSpec(listing.slug);
      await sleep(DELAY_MS);

      if (!spec) continue;

      const row = mapSpecToRow(spec, brand.displayName);
      if (!row) {
        console.log(`   ⏭  Skipped (pre-2020): ${listing.phone_name}`);
        continue;
      }

      seenSlugs.add(listing.slug);
      rows.push(row);
      fetched++;
      console.log(`   ✓ ${row.name} (${row.launchYear})`);
    }

    console.log(`   → ${fetched} phones added\n`);
    await sleep(DELAY_MS * 2); // extra pause between brands
  }

  // Persist to DB
  console.log(`\n🗑  Clearing existing phone records...`);
  await db.delete(phonesTable);

  if (rows.length === 0) {
    console.error("❌ No phones were scraped — aborting insert to avoid empty DB.");
    process.exit(1);
  }

  console.log(`💾 Inserting ${rows.length} phones...`);
  const CHUNK = 50;
  for (let i = 0; i < rows.length; i += CHUNK) {
    await db.insert(phonesTable).values(rows.slice(i, i + CHUNK));
    console.log(`   Inserted ${Math.min(i + CHUNK, rows.length)}/${rows.length}`);
  }

  console.log(`\n✅ Done! Seeded ${rows.length} phones from GSMArena (Phone Specs API method).`);
  process.exit(0);
}

main().catch((err) => {
  console.error("❌ Seed failed:", err);
  process.exit(1);
});
