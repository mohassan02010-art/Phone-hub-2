import { pgTable, serial, text, integer, real, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const phonesTable = pgTable("phones", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  brand: text("brand").notNull(),
  model: text("model").notNull(),
  launchYear: integer("launch_year").notNull(),
  launchDate: text("launch_date"),
  imageUrl: text("image_url").notNull(),
  priceUsd: real("price_usd"),
  rating: real("rating"),

  // Connectivity
  has5g: boolean("has_5g").notNull().default(false),
  hasNfc: boolean("has_nfc").notNull().default(true),
  hasWirelessCharging: boolean("has_wireless_charging").notNull().default(false),
  hasHeadphoneJack: boolean("has_headphone_jack").notNull().default(false),

  // Display
  displaySize: real("display_size"),
  displayType: text("display_type"),
  displayResolution: text("display_resolution"),
  displayRefreshRate: integer("display_refresh_rate"),
  displayNits: integer("display_nits"),

  // Performance
  processor: text("processor"),
  processorNm: integer("processor_nm"),
  ramOptions: text("ram_options"),
  storageOptions: text("storage_options"),
  ram: integer("ram"),
  storage: integer("storage"),

  // Camera
  mainCameraMp: real("main_camera_mp"),
  ultrawideCameraMp: real("ultrawide_camera_mp"),
  telephotoMp: real("telephoto_mp"),
  frontCameraMp: real("front_camera_mp"),
  videoResolution: text("video_resolution"),

  // Battery
  batteryMah: integer("battery_mah"),
  chargingWatts: integer("charging_watts"),

  // OS & Build
  os: text("os"),
  weight: real("weight"),
  thickness: real("thickness"),
  colors: text("colors"),
  simType: text("sim_type"),

  // Connectivity details
  wifi: text("wifi"),
  bluetooth: text("bluetooth"),
  usb: text("usb"),

  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertPhoneSchema = createInsertSchema(phonesTable).omit({ id: true, createdAt: true });
export type InsertPhone = z.infer<typeof insertPhoneSchema>;
export type Phone = typeof phonesTable.$inferSelect;
