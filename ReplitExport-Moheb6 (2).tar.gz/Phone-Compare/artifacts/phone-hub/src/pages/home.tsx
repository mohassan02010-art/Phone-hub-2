import React, { useState, useRef } from 'react';
import { Layout } from '@/components/layout';
import { PhoneCard } from '@/components/phone-card';
import { SkeletonCard, SkeletonGrid, SkeletonRow } from '@/components/skeleton';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import {
  ArrowRight, Activity, TrendingUp, Star, Zap,
  Cpu, Camera, BatteryFull, ChevronLeft, ChevronRight,
  Smartphone, BarChart2, Globe
} from 'lucide-react';
import {
  useGetFeaturedPhones,
  useGetStats,
  useListBrands,
  useListPhones,
} from '@workspace/api-client-react';

const RANKING_TABS = [
  { key: 'ram_desc', label: 'Performance', icon: Cpu, desc: 'Highest RAM' },
  { key: 'camera_desc', label: 'Camera', icon: Camera, desc: 'Most Megapixels' },
  { key: 'battery_desc', label: 'Battery', icon: BatteryFull, desc: 'Largest Capacity' },
] as const;

/* Shared scroll-reveal wrapper */
const Reveal = ({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) => (
  <motion.div
    initial={{ opacity: 0, y: 28 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: '-60px' }}
    transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
  >
    {children}
  </motion.div>
);

export default function Home() {
  const [activeRank, setActiveRank] = useState<'ram_desc' | 'camera_desc' | 'battery_desc'>('ram_desc');
  const latestRef = useRef<HTMLDivElement>(null);
  const popularRef = useRef<HTMLDivElement>(null);

  const { data: featuredPhones, isLoading: featuredLoading } = useGetFeaturedPhones({ limit: 8 });
  const { data: stats } = useGetStats();
  const { data: brands } = useListBrands();
  const { data: latestData, isLoading: latestLoading } = useListPhones({ sort: 'newest', limit: 10 });
  const { data: popularData, isLoading: popularLoading } = useListPhones({ sort: 'rating', limit: 8 });
  const { data: rankingData, isLoading: rankingLoading } = useListPhones({ sort: activeRank as any, limit: 10 });

  const scroll = (ref: React.RefObject<HTMLDivElement | null>, dir: 'left' | 'right') => {
    ref.current?.scrollBy({ left: dir === 'left' ? -320 : 320, behavior: 'smooth' });
  };

  const rankField = activeRank === 'ram_desc' ? 'ram' : activeRank === 'camera_desc' ? 'mainCameraMp' : 'batteryMah';
  const rankSuffix = activeRank === 'ram_desc' ? 'GB RAM' : activeRank === 'camera_desc' ? 'MP' : 'mAh';

  return (
    <Layout>
      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden min-h-[92vh] flex items-center border-b border-border">
        {/* Background layers */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_-10%,rgba(0,212,255,0.12),transparent)] pointer-events-none" />
        <div className="absolute inset-0 pointer-events-none opacity-[0.04]"
          style={{ backgroundImage: 'linear-gradient(rgba(255,255,255,1) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,1) 1px,transparent 1px)', backgroundSize: '48px 48px' }} />
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />

        <div className="container mx-auto px-4 relative z-10 py-24">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-primary/30 bg-primary/8 text-primary text-xs font-mono mb-8 uppercase tracking-[0.2em]">
                <Activity className="w-3 h-3 animate-pulse" />
                Live Database — {stats?.totalPhones?.toLocaleString() ?? '...'} Devices Indexed
              </div>

              <h1 className="text-6xl md:text-8xl font-black tracking-[-0.04em] mb-6 leading-[0.9]">
                <span className="text-foreground">EVERY SPEC.</span>
                <br />
                <span className="bg-gradient-to-r from-primary via-cyan-300 to-primary bg-clip-text text-transparent drop-shadow-[0_0_40px_rgba(0,212,255,0.3)]">
                  EVERY DETAIL.
                </span>
              </h1>

              <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed font-light">
                The definitive smartphone intelligence platform. Compare specs, discover rankings, and find your perfect device across {stats?.totalBrands ?? '...'} major brands.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <Link href="/catalog" className="group bg-primary text-primary-foreground px-8 py-3.5 rounded-xl font-bold tracking-wide hover:bg-primary/90 hover:shadow-[0_0_30px_rgba(0,212,255,0.35)] transition-all flex items-center gap-2 min-w-[200px] justify-center">
                  <Smartphone className="w-4 h-4" />
                  Browse Catalog
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link href="/compare" className="bg-secondary/60 backdrop-blur-sm border border-border text-foreground px-8 py-3.5 rounded-xl font-bold tracking-wide hover:bg-white/8 hover:border-primary/40 transition-all flex items-center gap-2 min-w-[200px] justify-center">
                  Compare Devices
                </Link>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Floating stat cards */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-4 px-4"
        >
          {[
            { label: 'Devices', value: stats?.totalPhones?.toLocaleString() ?? '...', icon: Smartphone },
            { label: 'Brands', value: stats?.totalBrands?.toLocaleString() ?? '...', icon: Globe },
            { label: '5G Ready', value: stats?.phonesWith5g?.toLocaleString() ?? '...', icon: Zap },
            { label: 'Avg Price', value: stats?.avgPriceUsd ? `$${Math.round(stats.avgPriceUsd)}` : '...', icon: TrendingUp },
          ].map(({ label, value, icon: Icon }) => (
            <div key={label} className="hidden md:flex flex-col items-center bg-card/60 backdrop-blur-sm border border-border px-5 py-3 rounded-xl gap-1">
              <Icon className="w-4 h-4 text-primary mb-1" />
              <span className="text-lg font-bold text-primary font-mono">{value}</span>
              <span className="text-[10px] uppercase tracking-widest text-muted-foreground font-mono">{label}</span>
            </div>
          ))}
        </motion.div>
      </section>

      {/* ── LATEST PHONES ────────────────────────────────────────────── */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Reveal>
            <SectionHeader
              icon={<TrendingUp className="w-5 h-5 text-primary" />}
              title="Latest Releases"
              subtitle="Freshest devices from top brands"
              href="/catalog?sort=newest"
            />
          </Reveal>
          <div className="relative">
            <button onClick={() => scroll(latestRef, 'left')} className="hidden md:flex absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 z-10 w-9 h-9 rounded-full bg-card border border-border items-center justify-center hover:border-primary/50 hover:text-primary transition-all shadow-lg">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div ref={latestRef} className="flex gap-5 overflow-x-auto pb-4 scroll-smooth scrollbar-hide" style={{ scrollbarWidth: 'none' }}>
              {latestLoading
                ? Array(6).fill(0).map((_, i) => (
                    <div key={i} className="flex-shrink-0 w-52">
                      <SkeletonCard delay={i * 60} />
                    </div>
                  ))
                : latestData?.phones?.map((phone, i) => (
                  <div key={phone.id} className="flex-shrink-0 w-52">
                    <div className="relative">
                      <div className="absolute top-2 left-2 z-20 bg-primary text-primary-foreground text-[9px] font-bold px-2 py-0.5 rounded-full font-mono uppercase tracking-wider">
                        {phone.launchYear}
                      </div>
                      <PhoneCard phone={phone} index={i} />
                    </div>
                  </div>
                ))
              }
            </div>
            <button onClick={() => scroll(latestRef, 'right')} className="hidden md:flex absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 z-10 w-9 h-9 rounded-full bg-card border border-border items-center justify-center hover:border-primary/50 hover:text-primary transition-all shadow-lg">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* ── MOST POPULAR ─────────────────────────────────────────────── */}
      <section className="py-20 bg-card/30 border-y border-border">
        <div className="container mx-auto px-4">
          <Reveal>
            <SectionHeader
              icon={<Star className="w-5 h-5 text-yellow-400" />}
              title="Most Popular"
              subtitle="Top-rated devices by user score"
              href="/catalog?sort=rating"
            />
          </Reveal>
          {popularLoading
            ? <SkeletonGrid count={8} cols={4} />
            : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
                {popularData?.phones?.map((phone, i) => (
                  <PhoneCard key={phone.id} phone={phone} index={i} rank={i + 1} />
                ))}
              </div>
            )
          }
        </div>
      </section>

      {/* ── RANKINGS ─────────────────────────────────────────────────── */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Reveal>
            <SectionHeader
              icon={<BarChart2 className="w-5 h-5 text-primary" />}
              title="Phone Rankings"
              subtitle="Find the best in every category"
            />
          </Reveal>

          {/* Tab switcher */}
          <Reveal delay={0.08}>
            <div className="flex gap-2 mb-8 p-1 bg-card border border-border rounded-xl w-fit">
              {RANKING_TABS.map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setActiveRank(tab.key)}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                    activeRank === tab.key
                      ? 'bg-primary text-primary-foreground shadow-[0_0_16px_rgba(0,212,255,0.3)]'
                      : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  {tab.label}
                </button>
              ))}
            </div>
          </Reveal>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Ranked list */}
            <div className="space-y-2">
              {rankingLoading
                ? Array(8).fill(0).map((_, i) => <SkeletonRow key={i} delay={i * 50} />)
                : rankingData?.phones?.filter(p => (p as any)[rankField]).map((phone, i) => {
                    const val = (phone as any)[rankField] as number;
                    const maxVal = rankingData.phones[0] ? (rankingData.phones[0] as any)[rankField] as number : 1;
                    const pct = Math.round((val / maxVal) * 100);
                    return (
                      <Link key={phone.id} href={`/phones/${phone.id}`}>
                        <div className={`group flex items-center gap-4 p-4 rounded-xl border transition-all cursor-pointer ${
                          i === 0 ? 'bg-primary/5 border-primary/30 hover:bg-primary/10' : 'bg-card border-border hover:border-primary/30 hover:bg-card/80'
                        }`}>
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0 ${
                            i === 0 ? 'bg-yellow-500 text-black' :
                            i === 1 ? 'bg-slate-400 text-black' :
                            i === 2 ? 'bg-orange-500 text-black' :
                            'bg-secondary text-muted-foreground border border-border'
                          }`}>{i + 1}</div>
                          <div className="w-10 h-12 flex-shrink-0">
                            <img src={phone.imageUrl} alt={phone.name} className="w-full h-full object-contain" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-[10px] text-primary font-mono uppercase">{phone.brand}</div>
                            <div className="font-semibold text-sm truncate">{phone.name}</div>
                            <div className="mt-1 h-1 bg-border rounded-full overflow-hidden">
                              <motion.div
                                className="h-full bg-primary rounded-full"
                                initial={{ width: 0 }}
                                animate={{ width: `${pct}%` }}
                                transition={{ duration: 0.5, delay: i * 0.04 }}
                              />
                            </div>
                          </div>
                          <div className="text-right flex-shrink-0">
                            <div className={`font-bold text-sm font-mono ${i === 0 ? 'text-primary' : 'text-foreground'}`}>
                              {val.toLocaleString()}
                            </div>
                            <div className="text-[10px] text-muted-foreground font-mono">{rankSuffix}</div>
                          </div>
                        </div>
                      </Link>
                    );
                  })
              }
            </div>

            {/* Top 3 visual showcase */}
            <div className="hidden md:flex flex-col gap-4">
              <div className="bg-gradient-to-br from-card to-card/50 border border-border rounded-2xl p-6 flex-1">
                <div className="text-xs font-mono text-muted-foreground uppercase tracking-widest mb-6">
                  {RANKING_TABS.find(t => t.key === activeRank)?.label} Podium
                </div>
                <div className="flex items-end justify-center gap-4 h-48">
                  {/* Silver (2nd) */}
                  {rankingData?.phones?.[1] && (
                    <div className="flex flex-col items-center gap-2 w-24">
                      <img src={rankingData.phones[1].imageUrl} alt="" className="w-16 h-20 object-contain" />
                      <div className="text-[10px] font-mono text-muted-foreground truncate w-full text-center">{rankingData.phones[1].name}</div>
                      <div className="w-full bg-slate-400/20 rounded-t-lg h-20 flex items-center justify-center border-t-2 border-slate-400">
                        <span className="text-slate-300 font-black text-xl">2</span>
                      </div>
                    </div>
                  )}
                  {/* Gold (1st) */}
                  {rankingData?.phones?.[0] && (
                    <div className="flex flex-col items-center gap-2 w-28">
                      <div className="text-yellow-400 text-lg">👑</div>
                      <img src={rankingData.phones[0].imageUrl} alt="" className="w-20 h-24 object-contain" />
                      <div className="text-[10px] font-mono font-bold text-primary truncate w-full text-center">{rankingData.phones[0].name}</div>
                      <div className="w-full bg-yellow-500/20 rounded-t-lg h-28 flex items-center justify-center border-t-2 border-yellow-500">
                        <span className="text-yellow-400 font-black text-2xl">1</span>
                      </div>
                    </div>
                  )}
                  {/* Bronze (3rd) */}
                  {rankingData?.phones?.[2] && (
                    <div className="flex flex-col items-center gap-2 w-24">
                      <img src={rankingData.phones[2].imageUrl} alt="" className="w-16 h-20 object-contain" />
                      <div className="text-[10px] font-mono text-muted-foreground truncate w-full text-center">{rankingData.phones[2].name}</div>
                      <div className="w-full bg-orange-600/20 rounded-t-lg h-14 flex items-center justify-center border-t-2 border-orange-500">
                        <span className="text-orange-400 font-black text-xl">3</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── FEATURED ─────────────────────────────────────────────────── */}
      <section className="py-20 bg-card/30 border-y border-border">
        <div className="container mx-auto px-4">
          <SectionHeader
            icon={<Zap className="w-5 h-5 text-primary" />}
            title="Featured Hardware"
            subtitle="Editor picks — top-rated flagship devices"
            href="/catalog"
          />
          {featuredLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
              {Array(8).fill(0).map((_, i) => <div key={i} className="h-[340px] bg-card border border-border rounded-2xl animate-pulse" />)}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5">
              {featuredPhones?.map((phone, i) => (
                <PhoneCard key={phone.id} phone={phone} index={i} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ── BRANDS ───────────────────────────────────────────────────── */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <p className="text-xs font-mono text-muted-foreground uppercase tracking-[0.3em] mb-3">Coverage</p>
            <h2 className="text-3xl font-black tracking-tight">All Major Manufacturers</h2>
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            {brands?.map((brand, i) => (
              <Link key={brand.name} href={`/catalog?brand=${encodeURIComponent(brand.name)}`}>
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.03 }}
                  className="group px-5 py-2.5 border border-border bg-card rounded-xl hover:border-primary/50 hover:bg-primary/5 hover:text-primary transition-all cursor-pointer"
                >
                  <span className="font-mono text-sm font-semibold">{brand.name}</span>
                  <span className="text-xs text-muted-foreground font-mono ml-2">({brand.count})</span>
                </motion.div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────── */}
      <section className="py-24 bg-card border-t border-border relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,212,255,0.06),transparent_60%)] pointer-events-none" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-black tracking-tight mb-4">
            Find Your Perfect Device
          </h2>
          <p className="text-muted-foreground text-lg mb-8 max-w-xl mx-auto">
            Compare any two phones side by side and get an instant winner analysis across every spec.
          </p>
          <Link href="/compare" className="inline-flex items-center gap-3 bg-primary text-primary-foreground px-10 py-4 rounded-xl font-bold text-lg hover:bg-primary/90 hover:shadow-[0_0_30px_rgba(0,212,255,0.4)] transition-all">
            Start Comparing
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </Layout>
  );
}

function SectionHeader({ icon, title, subtitle, href }: {
  icon: React.ReactNode;
  title: string;
  subtitle: string;
  href?: string;
}) {
  return (
    <div className="flex items-end justify-between mb-10">
      <div>
        <div className="flex items-center gap-2 mb-1.5">
          {icon}
          <span className="text-[11px] font-mono uppercase tracking-[0.2em] text-muted-foreground">{subtitle}</span>
        </div>
        <h2 className="text-3xl font-black tracking-tight">{title}</h2>
      </div>
      {href && (
        <Link href={href} className="hidden sm:flex items-center gap-1.5 text-primary hover:text-primary/80 font-mono text-xs uppercase tracking-widest transition-colors group">
          View All
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
        </Link>
      )}
    </div>
  );
}
