import React, { useState } from 'react';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import {
  BatteryMedium, Cpu, ScanLine, Waves,
  Star, Signal, ChevronRight
} from 'lucide-react';
import { Phone } from '@workspace/api-client-react';

interface PhoneCardProps {
  phone: Phone;
  index?: number;
  rank?: number;
  variant?: 'default' | 'compact' | 'horizontal';
}

/* rank badge colours */
const rankStyle = (r: number) =>
  r === 1 ? 'bg-yellow-500 text-black'
  : r === 2 ? 'bg-slate-400 text-black'
  : r === 3 ? 'bg-orange-500 text-black'
  : 'bg-secondary text-muted-foreground border border-border';

/* ── Horizontal / ranking list variant ─────────────────────────────────── */
export function PhoneCard({ phone, index = 0, rank, variant = 'default' }: PhoneCardProps) {
  const [imgError, setImgError] = useState(false);

  if (variant === 'horizontal') {
    return (
      <Link href={`/phones/${phone.id}`}>
        <motion.div
          initial={{ opacity: 0, x: -12 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.04, duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          whileHover={{ x: 3 }}
          className="group flex items-center gap-4 p-3 rounded-xl bg-card border border-border
                     hover:border-primary/40 hover:bg-white/[0.03] transition-colors cursor-pointer"
        >
          {rank && (
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0 ${rankStyle(rank)}`}>
              {rank}
            </div>
          )}
          <div className="w-12 h-14 flex-shrink-0 flex items-center justify-center">
            {!imgError
              ? <img src={phone.imageUrl} alt={phone.name} className="max-h-full max-w-full object-contain" onError={() => setImgError(true)} />
              : <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center text-muted-foreground text-xs font-bold">{phone.brand[0]}</div>
            }
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[10px] font-mono text-primary uppercase tracking-widest">{phone.brand}</div>
            <div className="font-semibold text-sm truncate text-foreground">{phone.name}</div>
          </div>
          <div className="text-right flex-shrink-0 flex items-center gap-2">
            <div>
              <div className="font-bold text-sm font-mono text-primary">{phone.priceUsd ? `$${phone.priceUsd}` : '—'}</div>
              {phone.rating && <div className="text-[10px] text-muted-foreground font-mono">★ {phone.rating.toFixed(1)}</div>}
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/40 group-hover:text-primary group-hover:translate-x-0.5 transition-all" />
          </div>
        </motion.div>
      </Link>
    );
  }

  /* ── Default card ────────────────────────────────────────────────────── */
  return (
    <Link href={`/phones/${phone.id}`}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.05, duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        className="phone-card group relative bg-card border border-border rounded-2xl overflow-hidden
                   flex flex-col h-full cursor-pointer"
      >
        {/* ── Rank badge ── */}
        {rank && (
          <div className={`absolute top-3 left-3 z-20 w-7 h-7 rounded-full flex items-center justify-center text-xs font-black shadow-lg ${rankStyle(rank)}`}>
            {rank}
          </div>
        )}

        {/* ── Feature pills (top strip) ── */}
        <div className={`absolute top-3 z-20 flex gap-1.5 ${rank ? 'left-12' : 'left-3'}`}>
          {phone.has5g && (
            <span className="inline-flex items-center gap-0.5 bg-background/70 backdrop-blur-sm border border-primary/30 text-primary text-[9px] font-bold px-1.5 py-0.5 rounded-md">
              <Signal className="w-2.5 h-2.5" />5G
            </span>
          )}
        </div>

        {phone.rating && (
          <div className="absolute top-3 right-3 z-20 inline-flex items-center gap-1 bg-background/70 backdrop-blur-sm border border-white/10 px-1.5 py-0.5 rounded-md">
            <Star className="w-2.5 h-2.5 fill-yellow-400 text-yellow-400" />
            <span className="text-[10px] font-bold text-white">{phone.rating.toFixed(1)}</span>
          </div>
        )}

        {/* ── Image area ── */}
        <div className="relative h-48 flex items-center justify-center overflow-hidden
                        bg-gradient-to-b from-white/[0.03] to-transparent px-6 pt-8 pb-4">
          {/* Radial glow (appears on hover via group) */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,212,255,0.06)_0%,transparent_70%)]
                          opacity-0 group-hover:opacity-100 transition-opacity duration-400 pointer-events-none" />

          {!imgError ? (
            <img
              src={phone.imageUrl}
              alt={phone.name}
              className="card-image relative z-10 max-h-full max-w-full object-contain
                         drop-shadow-[0_8px_20px_rgba(0,0,0,0.55)]"
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="flex flex-col items-center justify-center text-muted-foreground/30">
              <span className="text-4xl font-black">{phone.brand[0]}</span>
            </div>
          )}
        </div>

        {/* ── Content ── */}
        <div className="p-5 flex flex-col flex-grow">
          <p className="text-[10px] font-mono text-primary mb-1 uppercase tracking-widest">{phone.brand}</p>
          <h3 className="font-bold text-base leading-snug mb-3 text-foreground line-clamp-2
                         group-hover:text-primary/90 transition-colors duration-200">
            {phone.name}
          </h3>

          {/* Spec grid */}
          <div className="grid grid-cols-2 gap-x-3 gap-y-2 mt-auto text-[11px] text-muted-foreground font-mono mb-4">
            {phone.displaySize && (
              <div className="flex items-center gap-1.5">
                <ScanLine className="w-3 h-3 text-primary/40" />
                <span>{phone.displaySize}"</span>
              </div>
            )}
            {phone.processor && (
              <div className="flex items-center gap-1.5">
                <Cpu className="w-3 h-3 text-primary/40" />
                <span className="truncate">{phone.processor.split(' ').slice(0, 2).join(' ')}</span>
              </div>
            )}
            {phone.mainCameraMp && (
              <div className="flex items-center gap-1.5">
                <Waves className="w-3 h-3 text-primary/40" />
                <span>{phone.mainCameraMp}MP</span>
              </div>
            )}
            {phone.batteryMah && (
              <div className="flex items-center gap-1.5">
                <BatteryMedium className="w-3 h-3 text-primary/40" />
                <span>{phone.batteryMah}mAh</span>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="pt-3 border-t border-white/[0.06] flex items-center justify-between">
            <span className="text-[11px] font-mono text-muted-foreground/50">{phone.launchYear}</span>
            <span className="font-bold text-sm text-primary font-mono tracking-tight">
              {phone.priceUsd ? `$${phone.priceUsd}` : 'TBA'}
            </span>
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
