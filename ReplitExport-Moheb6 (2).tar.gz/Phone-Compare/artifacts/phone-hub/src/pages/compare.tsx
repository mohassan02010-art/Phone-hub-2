import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/layout';
import { useComparePhones, useListPhones } from '@workspace/api-client-react';
import { Search, X, Plus, Check, Scale, Trophy, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Compare() {
  const searchParams = new URLSearchParams(window.location.search);
  const initialIds = searchParams.get('ids');

  const [selectedIds, setSelectedIds] = useState<number[]>(
    initialIds ? initialIds.split(',').map(id => parseInt(id)).filter(id => !isNaN(id)) : []
  );

  const [isSearchOpen, setIsSearchOpen] = useState(selectedIds.length === 0);
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');

  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(searchQuery), 250);
    return () => clearTimeout(t);
  }, [searchQuery]);

  useEffect(() => {
    const url = new URL(window.location.href);
    if (selectedIds.length > 0) url.searchParams.set('ids', selectedIds.join(','));
    else url.searchParams.delete('ids');
    window.history.replaceState({}, '', url.toString());
  }, [selectedIds]);

  const { data: searchResults, isLoading: isSearchLoading } = useListPhones(
    { search: debouncedSearch, limit: 8 },
    { query: { enabled: !!debouncedSearch } }
  );

  const { data: comparisonData, isLoading: isCompareLoading } = useComparePhones(
    { ids: selectedIds.join(',') },
    { query: { enabled: selectedIds.length > 0 } }
  );

  const addPhone = (id: number) => {
    if (selectedIds.length >= 4 || selectedIds.includes(id)) return;
    setSelectedIds([...selectedIds, id]);
    setSearchQuery('');
    setIsSearchOpen(false);
  };

  const removePhone = (id: number) => setSelectedIds(selectedIds.filter(pid => pid !== id));

  // Returns { winnerId, values } for a numeric field
  const analyzeField = (field: string, mode: 'high' | 'low' = 'high') => {
    if (!comparisonData || comparisonData.length < 2) return { winnerId: null, values: {} as Record<number, number> };
    const values: Record<number, number> = {};
    comparisonData.forEach(p => {
      const v = (p as any)[field];
      if (typeof v === 'number') values[p.id] = v;
    });
    const nums = Object.values(values);
    if (nums.length < 2) return { winnerId: null, values };
    const best = mode === 'high' ? Math.max(...nums) : Math.min(...nums);
    const winners = Object.entries(values).filter(([, v]) => v === best);
    return { winnerId: winners.length === 1 ? parseInt(winners[0][0]) : null, values };
  };

  const specs = {
    rating:           analyzeField('rating', 'high'),
    priceUsd:         analyzeField('priceUsd', 'low'),
    batteryMah:       analyzeField('batteryMah', 'high'),
    displaySize:      analyzeField('displaySize', 'high'),
    displayRefreshRate: analyzeField('displayRefreshRate', 'high'),
    mainCameraMp:     analyzeField('mainCameraMp', 'high'),
    ram:              analyzeField('ram', 'high'),
    storage:          analyzeField('storage', 'high'),
    chargingWatts:    analyzeField('chargingWatts', 'high'),
    weight:           analyzeField('weight', 'low'),
    thickness:        analyzeField('thickness', 'low'),
    frontCameraMp:    analyzeField('frontCameraMp', 'high'),
  };

  // Count wins per phone for the score card
  const winCounts = comparisonData?.reduce((acc, p) => {
    acc[p.id] = 0;
    return acc;
  }, {} as Record<number, number>) ?? {};
  Object.values(specs).forEach(({ winnerId }) => {
    if (winnerId && winCounts[winnerId] !== undefined) winCounts[winnerId]++;
  });

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
            <Scale className="w-8 h-8 text-primary" />
            SIDE-BY-SIDE COMPARISON
          </h1>
          <p className="text-muted-foreground font-mono text-sm">Select up to 4 devices — best specs highlighted automatically</p>
        </div>

        {/* Device Cards Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <AnimatePresence>
            {comparisonData?.map(phone => (
              <motion.div
                key={`hdr-${phone.id}`}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-card border border-border rounded-xl p-4 relative group"
              >
                <button
                  onClick={() => removePhone(phone.id)}
                  className="absolute top-2 right-2 p-1.5 bg-destructive/20 text-destructive rounded-full opacity-0 group-hover:opacity-100 transition-opacity z-10"
                >
                  <X className="w-3 h-3" />
                </button>

                {/* Win score badge */}
                {winCounts[phone.id] > 0 && (
                  <div className="absolute top-2 left-2 flex items-center gap-1 bg-primary/15 text-primary border border-primary/30 rounded-full px-2 py-0.5 text-[10px] font-bold font-mono">
                    <Trophy className="w-2.5 h-2.5" />
                    {winCounts[phone.id]}
                  </div>
                )}

                <div className="h-32 mb-4 flex items-center justify-center mt-4">
                  <img src={phone.imageUrl} alt={phone.name} className="max-h-full max-w-full object-contain drop-shadow-lg" />
                </div>
                <div className="text-xs text-primary font-mono uppercase mb-0.5">{phone.brand}</div>
                <div className="font-bold text-sm leading-tight" title={phone.name}>{phone.name}</div>
                <div className="text-muted-foreground text-xs font-mono mt-1.5">{phone.priceUsd ? `$${phone.priceUsd}` : phone.launchYear}</div>
              </motion.div>
            ))}
          </AnimatePresence>

          {selectedIds.length < 4 && (
            <motion.div
              layout
              className="bg-card/30 border border-dashed border-border rounded-xl p-4 flex flex-col items-center justify-center min-h-[220px] cursor-pointer hover:bg-card/60 hover:border-primary/50 transition-all"
              onClick={() => setIsSearchOpen(true)}
            >
              <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center mb-3">
                <Plus className="w-6 h-6 text-primary" />
              </div>
              <span className="font-mono text-sm uppercase tracking-widest text-muted-foreground">Add Device</span>
            </motion.div>
          )}
        </div>

        {/* Search Modal */}
        <AnimatePresence>
          {isSearchOpen && (
            <div className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh] px-4 bg-background/80 backdrop-blur-sm">
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="bg-card border border-border rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden"
              >
                <div className="p-4 border-b border-border flex items-center gap-3">
                  <Search className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                  <input
                    type="text"
                    autoFocus
                    placeholder="Search devices to compare..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-1 bg-transparent border-none outline-none text-lg placeholder:text-muted-foreground/50"
                  />
                  {selectedIds.length > 0 && (
                    <button onClick={() => setIsSearchOpen(false)} className="p-2 hover:bg-secondary rounded-full flex-shrink-0">
                      <X className="w-5 h-5 text-muted-foreground" />
                    </button>
                  )}
                </div>
                <div className="max-h-[60vh] overflow-y-auto">
                  {isSearchLoading ? (
                    <div className="p-8 text-center text-muted-foreground font-mono text-sm animate-pulse">Searching database...</div>
                  ) : debouncedSearch && searchResults?.phones?.length === 0 ? (
                    <div className="p-8 text-center text-muted-foreground font-mono text-sm">No devices found for "{debouncedSearch}"</div>
                  ) : (
                    <div className="divide-y divide-border">
                      {searchResults?.phones?.map(phone => {
                        const isSelected = selectedIds.includes(phone.id);
                        return (
                          <div
                            key={`sr-${phone.id}`}
                            onClick={() => !isSelected && addPhone(phone.id)}
                            className={`p-4 flex items-center gap-4 transition-colors ${isSelected ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer hover:bg-secondary'}`}
                          >
                            <img src={phone.imageUrl} alt={phone.name} className="w-10 h-14 object-contain flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <div className="text-xs text-primary font-mono">{phone.brand}</div>
                              <div className="font-bold truncate">{phone.name}</div>
                              <div className="text-xs text-muted-foreground font-mono flex gap-3 mt-0.5">
                                <span>{phone.launchYear}</span>
                                {phone.priceUsd && <span>${phone.priceUsd}</span>}
                                {phone.ram && <span>{phone.ram}GB RAM</span>}
                              </div>
                            </div>
                            {isSelected
                              ? <div className="bg-primary/20 text-primary p-1.5 rounded-full"><Check className="w-4 h-4" /></div>
                              : <div className="bg-secondary text-foreground p-1.5 rounded-full"><Plus className="w-4 h-4" /></div>
                            }
                          </div>
                        );
                      })}
                      {!debouncedSearch && (
                        <div className="p-10 text-center text-muted-foreground font-mono text-sm">
                          Type a model name to begin
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Comparison Table */}
        {selectedIds.length > 0 && !isCompareLoading && comparisonData && comparisonData.length >= 2 && (
          <div className="bg-card border border-border rounded-xl overflow-hidden overflow-x-auto">
            <table className="w-full text-sm text-left" style={{ minWidth: `${200 + comparisonData.length * 200}px` }}>
              <tbody>
                <SectionHeader title="Basic Info" colSpan={comparisonData.length + 1} />
                <SpecRow label="Brand" data={comparisonData} field="brand" />
                <SpecRow label="Model" data={comparisonData} field="model" />
                <SpecRow label="Release" data={comparisonData} field="launchDate" fallback="launchYear" />
                <NumericRow label="Price" data={comparisonData} analysis={specs.priceUsd} prefix="$" mode="low" note="lower is better" />
                <NumericRow label="User Rating" data={comparisonData} analysis={specs.rating} suffix="/10" mode="high" />

                <SectionHeader title="Display" colSpan={comparisonData.length + 1} />
                <NumericRow label="Screen Size" data={comparisonData} analysis={specs.displaySize} suffix='"' mode="high" />
                <SpecRow label="Panel Type" data={comparisonData} field="displayType" />
                <SpecRow label="Resolution" data={comparisonData} field="displayResolution" />
                <NumericRow label="Refresh Rate" data={comparisonData} analysis={specs.displayRefreshRate} suffix="Hz" mode="high" />
                <NumericRow label="Weight" data={comparisonData} analysis={specs.weight} suffix="g" mode="low" note="lighter is better" />
                <NumericRow label="Thickness" data={comparisonData} analysis={specs.thickness} suffix="mm" mode="low" note="thinner is better" />

                <SectionHeader title="Performance" colSpan={comparisonData.length + 1} />
                <SpecRow label="OS" data={comparisonData} field="os" />
                <SpecRow label="Processor" data={comparisonData} field="processor" />
                <SpecRow label="Process Node" data={comparisonData} field="processorNm" suffix="nm" />
                <NumericRow label="RAM" data={comparisonData} analysis={specs.ram} suffix="GB" mode="high" />
                <NumericRow label="Storage" data={comparisonData} analysis={specs.storage} suffix="GB" mode="high" />

                <SectionHeader title="Cameras" colSpan={comparisonData.length + 1} />
                <NumericRow label="Main Camera" data={comparisonData} analysis={specs.mainCameraMp} suffix="MP" mode="high" />
                <NumericRow label="Front Camera" data={comparisonData} analysis={specs.frontCameraMp} suffix="MP" mode="high" />
                <SpecRow label="Ultrawide" data={comparisonData} field="ultrawideCameraMp" suffix="MP" />
                <SpecRow label="Telephoto" data={comparisonData} field="telephotoMp" suffix="MP" />
                <SpecRow label="Video" data={comparisonData} field="videoResolution" />

                <SectionHeader title="Battery & Charging" colSpan={comparisonData.length + 1} />
                <NumericRow label="Battery" data={comparisonData} analysis={specs.batteryMah} suffix="mAh" mode="high" />
                <NumericRow label="Charging Speed" data={comparisonData} analysis={specs.chargingWatts} suffix="W" mode="high" />

                <SectionHeader title="Connectivity" colSpan={comparisonData.length + 1} />
                <BoolRow label="5G" data={comparisonData} field="has5g" />
                <BoolRow label="NFC" data={comparisonData} field="hasNfc" />
                <BoolRow label="Wireless Charging" data={comparisonData} field="hasWirelessCharging" />
                <BoolRow label="Headphone Jack" data={comparisonData} field="hasHeadphoneJack" />
                <SpecRow label="Wi-Fi" data={comparisonData} field="wifi" />
                <SpecRow label="Bluetooth" data={comparisonData} field="bluetooth" />
                <SpecRow label="USB" data={comparisonData} field="usb" />
              </tbody>
            </table>
          </div>
        )}

        {/* empty state */}
        {selectedIds.length === 0 && (
          <div className="text-center py-20 border border-dashed border-border rounded-xl bg-card/30">
            <Scale className="w-12 h-12 text-muted-foreground/40 mx-auto mb-4" />
            <p className="text-muted-foreground font-mono text-sm">Add at least 2 devices to start comparing</p>
          </div>
        )}
      </div>
    </Layout>
  );
}

/* ── Sub-components ── */

function SectionHeader({ title, colSpan }: { title: string; colSpan: number }) {
  return (
    <tr className="bg-secondary/80 border-y border-border">
      <td colSpan={colSpan} className="px-4 py-3 font-bold text-primary tracking-widest uppercase text-xs">
        {title}
      </td>
    </tr>
  );
}

/** Plain text / non-numeric row */
function SpecRow({ label, data, field, fallback, suffix = '' }: {
  label: string; data: any[]; field: string; fallback?: string; suffix?: string;
}) {
  return (
    <tr className="border-b border-border/50 hover:bg-white/[0.02] transition-colors">
      <td className="px-4 py-3 font-medium text-muted-foreground w-48 sticky left-0 bg-card border-r border-border z-10 shadow-[6px_0_12px_-6px_rgba(0,0,0,0.4)]">
        {label}
      </td>
      {data.map(phone => {
        const val = phone[field] ?? (fallback ? phone[fallback] : null);
        return (
          <td key={`${phone.id}-${field}`} className="px-4 py-3 min-w-[180px] text-sm">
            {val !== null && val !== undefined && val !== ''
              ? <>{val}{suffix}</>
              : <span className="text-muted-foreground/40">—</span>
            }
          </td>
        );
      })}
    </tr>
  );
}

/** Numeric row with score bar + winner badge */
function NumericRow({ label, data, analysis, prefix = '', suffix = '', mode, note }: {
  label: string;
  data: any[];
  analysis: { winnerId: number | null; values: Record<number, number> };
  prefix?: string;
  suffix?: string;
  mode: 'high' | 'low';
  note?: string;
}) {
  const { winnerId, values } = analysis;
  const nums = Object.values(values).filter(v => typeof v === 'number');
  const max = nums.length ? Math.max(...nums) : 0;
  const min = nums.length ? Math.min(...nums) : 0;
  const range = max - min;

  return (
    <tr className="border-b border-border/50 hover:bg-white/[0.02] transition-colors">
      <td className="px-4 py-3 font-medium text-muted-foreground w-48 sticky left-0 bg-card border-r border-border z-10 shadow-[6px_0_12px_-6px_rgba(0,0,0,0.4)]">
        <div>{label}</div>
        {note && <div className="text-[10px] text-muted-foreground/50 font-mono mt-0.5">{note}</div>}
      </td>
      {data.map(phone => {
        const val = values[phone.id];
        const isWinner = winnerId === phone.id;
        const hasVal = val !== undefined && val !== null;

        // bar fill: 0–100%, where 100% = best value
        let barPct = 0;
        if (hasVal && range > 0) {
          barPct = mode === 'high'
            ? ((val - min) / range) * 100
            : ((max - val) / range) * 100;
        } else if (hasVal && range === 0) {
          barPct = 100;
        }

        // "X% better" vs second best
        let pctBetter: string | null = null;
        if (isWinner && range > 0) {
          const others = nums.filter(n => n !== val);
          if (others.length) {
            const secondBest = mode === 'high' ? Math.max(...others) : Math.min(...others);
            const diff = mode === 'high'
              ? ((val - secondBest) / secondBest) * 100
              : ((secondBest - val) / secondBest) * 100;
            if (diff > 0.5) pctBetter = `+${diff.toFixed(0)}%`;
          }
        }

        return (
          <td
            key={`${phone.id}-n`}
            className={`px-4 py-2.5 min-w-[180px] ${isWinner ? 'bg-primary/5' : ''}`}
          >
            {hasVal ? (
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  {isWinner && <Trophy className="w-3 h-3 text-primary flex-shrink-0" />}
                  <span className={`font-mono text-sm ${isWinner ? 'text-primary font-bold' : ''}`}>
                    {prefix}{val.toLocaleString()}{suffix}
                  </span>
                  {pctBetter && (
                    <span className="flex items-center gap-0.5 text-[10px] font-bold text-primary bg-primary/10 rounded-full px-1.5 py-0.5 font-mono">
                      <ChevronUp className="w-2.5 h-2.5" />
                      {pctBetter}
                    </span>
                  )}
                </div>
                {/* Score bar */}
                <div className="h-1.5 w-full bg-border/60 rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full rounded-full ${isWinner ? 'bg-primary' : 'bg-muted-foreground/30'}`}
                    initial={{ width: 0 }}
                    animate={{ width: `${barPct}%` }}
                    transition={{ duration: 0.5, ease: 'easeOut' }}
                  />
                </div>
              </div>
            ) : (
              <span className="text-muted-foreground/40 text-sm">—</span>
            )}
          </td>
        );
      })}
    </tr>
  );
}

/** Boolean row */
function BoolRow({ label, data, field }: { label: string; data: any[]; field: string }) {
  return (
    <tr className="border-b border-border/50 hover:bg-white/[0.02] transition-colors">
      <td className="px-4 py-3 font-medium text-muted-foreground w-48 sticky left-0 bg-card border-r border-border z-10 shadow-[6px_0_12px_-6px_rgba(0,0,0,0.4)]">
        {label}
      </td>
      {data.map(phone => {
        const val = (phone as any)[field];
        return (
          <td key={`${phone.id}-${field}`} className="px-4 py-3 min-w-[180px]">
            {val === true
              ? <span className="inline-flex items-center gap-1.5 text-primary text-xs font-mono"><Check className="w-4 h-4" /> Yes</span>
              : val === false
              ? <span className="inline-flex items-center gap-1.5 text-muted-foreground/40 text-xs font-mono"><X className="w-4 h-4" /> No</span>
              : <span className="text-muted-foreground/40">—</span>
            }
          </td>
        );
      })}
    </tr>
  );
}
