import React from 'react';
import { Layout } from '@/components/layout';
import { 
  useGetStats, 
  useGetPriceDistribution, 
  useGetBrandsByCount, 
  useGetYearlyReleases 
} from '@workspace/api-client-react';
import { BarChart3, TrendingUp, Smartphone, Layers, Activity } from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';
import { motion } from 'framer-motion';

const COLORS = ['#00d4ff', '#0095ff', '#0065ff', '#3b3b3b', '#1f2937'];

export default function Analytics() {
  const { data: stats, isLoading: isStatsLoading } = useGetStats();
  const { data: priceDist, isLoading: isPriceDistLoading } = useGetPriceDistribution();
  const { data: brandsDist, isLoading: isBrandsLoading } = useGetBrandsByCount();
  const { data: yearlyDist, isLoading: isYearlyLoading } = useGetYearlyReleases();

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border p-3 rounded-md shadow-xl backdrop-blur-sm">
          <p className="text-muted-foreground font-mono text-xs mb-1">{label}</p>
          {payload.map((p: any, i: number) => (
            <p key={i} className="font-bold text-sm" style={{ color: p.color || '#00d4ff' }}>
              {p.name === 'count' ? 'Devices' : p.name}: {p.value}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight mb-2 flex items-center gap-3">
              <Activity className="w-8 h-8 text-primary" />
              MARKET INTELLIGENCE
            </h1>
            <p className="text-muted-foreground font-mono text-sm">Real-time database analytics and trends</p>
          </div>
          
          <div className="hidden sm:flex items-center gap-2 bg-secondary border border-border px-3 py-1.5 rounded-sm font-mono text-xs text-primary">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            LIVE DATA
          </div>
        </div>

        {/* Top Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard 
            title="Total Devices" 
            value={stats?.totalPhones} 
            icon={Smartphone} 
            loading={isStatsLoading} 
          />
          <StatCard 
            title="Tracked Brands" 
            value={stats?.totalBrands} 
            icon={Layers} 
            loading={isStatsLoading} 
          />
          <StatCard 
            title="Market Avg Price" 
            value={stats?.avgPriceUsd ? `$${Math.round(stats.avgPriceUsd)}` : null} 
            icon={TrendingUp} 
            loading={isStatsLoading} 
          />
          <StatCard 
            title="5G Adoption Rate" 
            value={stats ? `${Math.round((stats.phonesWith5g / stats.totalPhones) * 100)}%` : null} 
            icon={BarChart3} 
            loading={isStatsLoading} 
          />
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Yearly Releases */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-card border border-border rounded-xl p-6 shadow-sm"
          >
            <h3 className="text-sm font-mono text-muted-foreground uppercase tracking-widest mb-6">Yearly Releases</h3>
            <div className="h-[300px] w-full">
              {isYearlyLoading ? <ChartSkeleton /> : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={yearlyDist}>
                    <defs>
                      <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#00d4ff" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#00d4ff" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
                    <XAxis dataKey="year" stroke="#4b5563" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis stroke="#4b5563" fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="count" stroke="#00d4ff" strokeWidth={2} fillOpacity={1} fill="url(#colorCount)" />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
          </motion.div>

          {/* Market Share by Brand */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-card border border-border rounded-xl p-6 shadow-sm flex flex-col"
          >
            <h3 className="text-sm font-mono text-muted-foreground uppercase tracking-widest mb-6">Database Share by Brand</h3>
            <div className="flex-1 flex items-center justify-center">
              <div className="h-[300px] w-full">
                {isBrandsLoading ? <ChartSkeleton /> : (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={brandsDist?.slice(0, 8)}
                        cx="50%"
                        cy="50%"
                        innerRadius={80}
                        outerRadius={110}
                        paddingAngle={2}
                        dataKey="count"
                        stroke="none"
                      >
                        {brandsDist?.slice(0, 8).map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomTooltip />} />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </div>
              {/* Custom Legend */}
              <div className="w-1/3 flex flex-col gap-2 justify-center pl-4">
                {brandsDist?.slice(0, 5).map((entry, i) => (
                  <div key={entry.brand} className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                    <span className="text-xs font-mono truncate">{entry.brand}</span>
                    <span className="text-xs font-bold text-muted-foreground ml-auto">{entry.count}</span>
                  </div>
                ))}
                {(brandsDist?.length || 0) > 5 && (
                  <div className="text-xs text-muted-foreground font-mono mt-2 pt-2 border-t border-border">
                    + {(brandsDist?.length || 0) - 5} more
                  </div>
                )}
              </div>
            </div>
          </motion.div>

          {/* Price Distribution */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-card border border-border rounded-xl p-6 shadow-sm lg:col-span-2"
          >
            <h3 className="text-sm font-mono text-muted-foreground uppercase tracking-widest mb-6">Price Segment Analysis</h3>
            <div className="h-[350px] w-full">
              {isPriceDistLoading ? <ChartSkeleton /> : (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={priceDist} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" vertical={false} />
                    <XAxis dataKey="segment" stroke="#4b5563" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis yAxisId="left" stroke="#4b5563" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis yAxisId="right" orientation="right" stroke="#00d4ff" fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar yAxisId="left" dataKey="count" name="Devices" fill="#3b3b3b" radius={[4, 4, 0, 0]}>
                      {priceDist?.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={index === priceDist.length - 1 ? '#00d4ff' : '#1f2937'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </motion.div>

        </div>
      </div>
    </Layout>
  );
}

function StatCard({ title, value, icon: Icon, loading }: any) {
  return (
    <div className="bg-card border border-border rounded-xl p-5 relative overflow-hidden group">
      <div className="absolute right-0 top-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
        <Icon className="w-16 h-16" />
      </div>
      <div className="text-xs font-mono text-muted-foreground uppercase tracking-widest mb-2">
        {title}
      </div>
      <div className="text-3xl font-bold text-foreground">
        {loading ? <div className="h-9 w-24 bg-secondary rounded animate-pulse" /> : value}
      </div>
    </div>
  );
}

function ChartSkeleton() {
  return (
    <div className="w-full h-full flex items-end justify-between gap-2 p-4 animate-pulse">
      {[40, 70, 45, 90, 65, 30, 80, 50, 100].map((h, i) => (
        <div key={i} className="w-full bg-secondary/50 rounded-t-sm" style={{ height: `${h}%` }} />
      ))}
    </div>
  );
}
