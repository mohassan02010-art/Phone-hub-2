import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/layout';
import { PhoneCard } from '@/components/phone-card';
import { useListPhones, useListBrands } from '@workspace/api-client-react';
import { Search, Filter, SlidersHorizontal, ChevronLeft, ChevronRight, X, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Collapsible filter section
function FilterSection({ title, children, defaultOpen = true }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-border/50 pb-5">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between text-xs font-mono uppercase tracking-widest text-muted-foreground hover:text-foreground transition-colors mb-3"
      >
        {title}
        {open ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
      </button>
      {open && <div>{children}</div>}
    </div>
  );
}

// Chip-style select button
function ChipButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-1.5 rounded-sm text-xs font-mono border transition-colors ${
        active
          ? 'bg-primary text-background border-primary'
          : 'bg-card border-border hover:border-primary/50 text-muted-foreground hover:text-foreground'
      }`}
    >
      {children}
    </button>
  );
}

// Count active filters
function countActive(filters: any, search: string): number {
  let n = 0;
  if (search) n++;
  if (filters.brand) n++;
  if (filters.has5g) n++;
  if (filters.hasNfc) n++;
  if (filters.minPrice || filters.maxPrice) n++;
  if (filters.minRam) n++;
  if (filters.minStorage) n++;
  if (filters.minBattery) n++;
  if (filters.minCamera) n++;
  if (filters.minDisplay || filters.maxDisplay) n++;
  return n;
}

const RAM_OPTIONS = [4, 6, 8, 12, 16];
const STORAGE_OPTIONS = [64, 128, 256, 512, 1024];
const BATTERY_OPTIONS = [3000, 4000, 5000, 6000];
const CAMERA_OPTIONS = [12, 48, 100, 200];
const DISPLAY_PRESETS = [
  { label: 'Any', min: null, max: null },
  { label: '< 6"', min: null, max: 6.0 },
  { label: '6"–6.5"', min: 6.0, max: 6.5 },
  { label: '6.5"–7"', min: 6.5, max: 7.0 },
  { label: '> 7"', min: 7.0, max: null },
];

export default function Catalog() {
  const searchParams = new URLSearchParams(window.location.search);
  const initialSearch = searchParams.get('search') || '';
  const initialBrand = searchParams.get('brand') || '';

  const [search, setSearch] = useState(initialSearch);
  const [debouncedSearch, setDebouncedSearch] = useState(initialSearch);

  const [filters, setFilters] = useState({
    brand: initialBrand,
    has5g: searchParams.get('has5g') === 'true' ? true : null as boolean | null,
    hasNfc: searchParams.get('hasNfc') === 'true' ? true : null as boolean | null,
    sort: 'newest' as string,
    minPrice: '' as string,
    maxPrice: '' as string,
    minRam: null as number | null,
    minStorage: null as number | null,
    minBattery: null as number | null,
    minCamera: null as number | null,
    minDisplay: null as number | null,
    maxDisplay: null as number | null,
  });

  const [page, setPage] = useState(1);
  const limit = 12;

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => { setDebouncedSearch(search); setPage(1); }, 400);
    return () => clearTimeout(t);
  }, [search]);

  const handleFilterChange = (key: string, value: any) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setPage(1);
  };

  const resetAll = () => {
    setSearch('');
    setDebouncedSearch('');
    setFilters({ brand: '', has5g: null, hasNfc: null, sort: 'newest', minPrice: '', maxPrice: '', minRam: null, minStorage: null, minBattery: null, minCamera: null, minDisplay: null, maxDisplay: null });
    setPage(1);
    setShowMobileFilters(false);
  };

  const { data: phoneData, isLoading } = useListPhones({
    search: debouncedSearch || null,
    brand: filters.brand || null,
    has5g: filters.has5g,
    hasNfc: filters.hasNfc,
    sort: filters.sort as any,
    minPrice: filters.minPrice ? parseFloat(filters.minPrice) : null,
    maxPrice: filters.maxPrice ? parseFloat(filters.maxPrice) : null,
    minRam: filters.minRam,
    minStorage: filters.minStorage,
    minBattery: filters.minBattery,
    minCamera: filters.minCamera,
    minDisplay: filters.minDisplay,
    maxDisplay: filters.maxDisplay,
    page,
    limit,
  });

  const { data: brands } = useListBrands();
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  const activeCount = countActive(filters, search);

  const displayPresetActive = DISPLAY_PRESETS.findIndex(
    p => p.min === filters.minDisplay && p.max === filters.maxDisplay
  );

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">

          {/* Mobile Filter Toggle */}
          <div className="md:hidden flex items-center justify-between mb-2">
            <h1 className="text-2xl font-bold tracking-tight">DEVICE CATALOG</h1>
            <button
              onClick={() => setShowMobileFilters(true)}
              className="relative flex items-center gap-2 bg-secondary px-4 py-2 rounded-md text-sm font-mono border border-border"
            >
              <Filter className="w-4 h-4" /> Filters
              {activeCount > 0 && (
                <span className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-primary text-background text-[10px] font-bold flex items-center justify-center">
                  {activeCount}
                </span>
              )}
            </button>
          </div>

          {/* Sidebar */}
          <aside className={`
            fixed inset-0 z-50 bg-background/95 backdrop-blur-md p-6 overflow-y-auto transition-transform duration-300
            md:relative md:inset-auto md:z-0 md:bg-transparent md:backdrop-blur-none md:p-0 md:w-64 md:flex-shrink-0 md:translate-x-0
            ${showMobileFilters ? 'translate-x-0' : '-translate-x-full'}
          `}>
            <div className="flex items-center justify-between md:hidden mb-6">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5 text-primary" /> Filters
              </h2>
              <button onClick={() => setShowMobileFilters(false)} className="p-2 bg-secondary rounded-full">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-5 sticky top-24">
              {/* Search */}
              <FilterSection title="Search" defaultOpen>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <input
                    type="text"
                    placeholder="Model name, chip..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="w-full bg-card border border-border rounded-sm py-2 pl-9 pr-4 text-sm focus:outline-none focus:border-primary transition-colors"
                  />
                </div>
              </FilterSection>

              {/* Brand */}
              <FilterSection title="Manufacturer">
                <select
                  value={filters.brand}
                  onChange={(e) => handleFilterChange('brand', e.target.value)}
                  className="w-full bg-card border border-border rounded-sm py-2.5 px-3 text-sm focus:outline-none focus:border-primary appearance-none cursor-pointer"
                >
                  <option value="">All Brands</option>
                  {brands?.map(b => (
                    <option key={b.name} value={b.name}>{b.name} ({b.count})</option>
                  ))}
                </select>
              </FilterSection>

              {/* Price */}
              <FilterSection title="Price (USD)" defaultOpen={false}>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    placeholder="Min"
                    value={filters.minPrice}
                    onChange={(e) => handleFilterChange('minPrice', e.target.value)}
                    className="w-full bg-card border border-border rounded-sm py-2 px-3 text-sm focus:outline-none focus:border-primary"
                    min={0}
                  />
                  <span className="text-muted-foreground text-xs">–</span>
                  <input
                    type="number"
                    placeholder="Max"
                    value={filters.maxPrice}
                    onChange={(e) => handleFilterChange('maxPrice', e.target.value)}
                    className="w-full bg-card border border-border rounded-sm py-2 px-3 text-sm focus:outline-none focus:border-primary"
                    min={0}
                  />
                </div>
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {[['Budget', '', '300'], ['Mid', '300', '700'], ['Flagship', '700', '']].map(([label, min, max]) => (
                    <ChipButton
                      key={label}
                      active={filters.minPrice === min && filters.maxPrice === max}
                      onClick={() => { handleFilterChange('minPrice', min); handleFilterChange('maxPrice', max); }}
                    >
                      {label}
                    </ChipButton>
                  ))}
                </div>
              </FilterSection>

              {/* RAM */}
              <FilterSection title="RAM (min GB)" defaultOpen={false}>
                <div className="flex flex-wrap gap-1.5">
                  <ChipButton active={filters.minRam === null} onClick={() => handleFilterChange('minRam', null)}>Any</ChipButton>
                  {RAM_OPTIONS.map(gb => (
                    <ChipButton
                      key={gb}
                      active={filters.minRam === gb}
                      onClick={() => handleFilterChange('minRam', filters.minRam === gb ? null : gb)}
                    >
                      {gb}GB+
                    </ChipButton>
                  ))}
                </div>
              </FilterSection>

              {/* Storage */}
              <FilterSection title="Storage (min)" defaultOpen={false}>
                <div className="flex flex-wrap gap-1.5">
                  <ChipButton active={filters.minStorage === null} onClick={() => handleFilterChange('minStorage', null)}>Any</ChipButton>
                  {STORAGE_OPTIONS.map(gb => (
                    <ChipButton
                      key={gb}
                      active={filters.minStorage === gb}
                      onClick={() => handleFilterChange('minStorage', filters.minStorage === gb ? null : gb)}
                    >
                      {gb >= 1000 ? `${gb / 1000}TB` : `${gb}GB`}+
                    </ChipButton>
                  ))}
                </div>
              </FilterSection>

              {/* Battery */}
              <FilterSection title="Battery (min mAh)" defaultOpen={false}>
                <div className="flex flex-wrap gap-1.5">
                  <ChipButton active={filters.minBattery === null} onClick={() => handleFilterChange('minBattery', null)}>Any</ChipButton>
                  {BATTERY_OPTIONS.map(mah => (
                    <ChipButton
                      key={mah}
                      active={filters.minBattery === mah}
                      onClick={() => handleFilterChange('minBattery', filters.minBattery === mah ? null : mah)}
                    >
                      {mah >= 1000 ? `${mah / 1000}k` : mah}+
                    </ChipButton>
                  ))}
                </div>
              </FilterSection>

              {/* Camera */}
              <FilterSection title="Main Camera (min MP)" defaultOpen={false}>
                <div className="flex flex-wrap gap-1.5">
                  <ChipButton active={filters.minCamera === null} onClick={() => handleFilterChange('minCamera', null)}>Any</ChipButton>
                  {CAMERA_OPTIONS.map(mp => (
                    <ChipButton
                      key={mp}
                      active={filters.minCamera === mp}
                      onClick={() => handleFilterChange('minCamera', filters.minCamera === mp ? null : mp)}
                    >
                      {mp}MP+
                    </ChipButton>
                  ))}
                </div>
              </FilterSection>

              {/* Display */}
              <FilterSection title="Display Size" defaultOpen={false}>
                <div className="flex flex-wrap gap-1.5">
                  {DISPLAY_PRESETS.map((preset, i) => (
                    <ChipButton
                      key={i}
                      active={displayPresetActive === i}
                      onClick={() => {
                        handleFilterChange('minDisplay', preset.min);
                        handleFilterChange('maxDisplay', preset.max);
                      }}
                    >
                      {preset.label}
                    </ChipButton>
                  ))}
                </div>
              </FilterSection>

              {/* Features */}
              <FilterSection title="Features">
                <div className="space-y-2">
                  {[
                    { key: 'has5g', label: '5G Connectivity', val: filters.has5g },
                    { key: 'hasNfc', label: 'NFC Support', val: filters.hasNfc },
                  ].map(({ key, label, val }) => (
                    <label key={key} className="flex items-center gap-3 cursor-pointer group" onClick={() => handleFilterChange(key, val ? null : true)}>
                      <div className={`w-5 h-5 rounded-[4px] border flex items-center justify-center transition-colors ${val ? 'bg-primary border-primary' : 'bg-card border-border group-hover:border-primary/50'}`}>
                        {val && <div className="w-2.5 h-2.5 bg-background rounded-[1px]" />}
                      </div>
                      <span className="text-sm">{label}</span>
                    </label>
                  ))}
                </div>
              </FilterSection>

              {/* Sort */}
              <FilterSection title="Sort By">
                <select
                  value={filters.sort}
                  onChange={(e) => handleFilterChange('sort', e.target.value)}
                  className="w-full bg-card border border-border rounded-sm py-2.5 px-3 text-sm focus:outline-none focus:border-primary appearance-none cursor-pointer"
                >
                  <option value="newest">Release Date (Newest)</option>
                  <option value="oldest">Release Date (Oldest)</option>
                  <option value="price_desc">Price (High to Low)</option>
                  <option value="price_asc">Price (Low to High)</option>
                  <option value="rating">User Rating</option>
                </select>
              </FilterSection>

              {activeCount > 0 && (
                <button
                  onClick={resetAll}
                  className="w-full py-2 border border-destructive/50 text-destructive text-sm font-mono hover:bg-destructive/10 rounded-sm transition-colors flex items-center justify-center gap-2"
                >
                  <X className="w-3.5 h-3.5" /> Reset {activeCount} filter{activeCount !== 1 ? 's' : ''}
                </button>
              )}
            </div>
          </aside>

          {/* Main Content */}
          <main className="flex-1 min-w-0">
            <div className="hidden md:flex items-center justify-between mb-8 pb-4 border-b border-border">
              <h1 className="text-3xl font-bold tracking-tight">DEVICE CATALOG</h1>
              <div className="text-sm font-mono text-muted-foreground">
                {isLoading ? 'Loading...' : `${phoneData?.total ?? 0} devices found`}
              </div>
            </div>

            {/* Active filter chips (desktop) */}
            {activeCount > 0 && (
              <div className="hidden md:flex flex-wrap gap-2 mb-6">
                {debouncedSearch && <ActiveChip label={`"${debouncedSearch}"`} onRemove={() => { setSearch(''); setDebouncedSearch(''); }} />}
                {filters.brand && <ActiveChip label={filters.brand} onRemove={() => handleFilterChange('brand', '')} />}
                {filters.has5g && <ActiveChip label="5G" onRemove={() => handleFilterChange('has5g', null)} />}
                {filters.hasNfc && <ActiveChip label="NFC" onRemove={() => handleFilterChange('hasNfc', null)} />}
                {(filters.minPrice || filters.maxPrice) && <ActiveChip label={`$${filters.minPrice || 0}–$${filters.maxPrice || '∞'}`} onRemove={() => { handleFilterChange('minPrice', ''); handleFilterChange('maxPrice', ''); }} />}
                {filters.minRam && <ActiveChip label={`RAM ≥ ${filters.minRam}GB`} onRemove={() => handleFilterChange('minRam', null)} />}
                {filters.minStorage && <ActiveChip label={`Storage ≥ ${filters.minStorage >= 1000 ? `${filters.minStorage / 1000}TB` : `${filters.minStorage}GB`}`} onRemove={() => handleFilterChange('minStorage', null)} />}
                {filters.minBattery && <ActiveChip label={`Battery ≥ ${filters.minBattery}mAh`} onRemove={() => handleFilterChange('minBattery', null)} />}
                {filters.minCamera && <ActiveChip label={`Camera ≥ ${filters.minCamera}MP`} onRemove={() => handleFilterChange('minCamera', null)} />}
                {(filters.minDisplay || filters.maxDisplay) && <ActiveChip label={`${filters.minDisplay ?? 0}"–${filters.maxDisplay ?? '∞'}`} onRemove={() => { handleFilterChange('minDisplay', null); handleFilterChange('maxDisplay', null); }} />}
              </div>
            )}

            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {[...Array(8)].map((_, i) => (
                  <SkeletonCard key={i} delay={i * 50} />
                ))}
              </div>
            ) : !phoneData?.phones?.length ? (
              <div className="text-center py-32 border border-dashed border-border rounded-xl bg-card/50">
                <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="text-xl font-bold mb-2">No devices found</h3>
                <p className="text-muted-foreground mb-4">Try adjusting your filters or search query.</p>
                {activeCount > 0 && (
                  <button onClick={resetAll} className="text-primary font-mono text-sm hover:underline">
                    Clear all filters
                  </button>
                )}
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {phoneData.phones.map((phone, i) => (
                    <PhoneCard key={phone.id} phone={phone} index={i} />
                  ))}
                </div>

                {phoneData.total > limit && (
                  <div className="flex items-center justify-center gap-4 mt-12 pt-8 border-t border-border">
                    <button
                      onClick={() => setPage(p => Math.max(1, p - 1))}
                      disabled={page === 1}
                      className="p-2 border border-border rounded-sm hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <span className="font-mono text-sm">
                      Page <span className="text-primary font-bold">{page}</span> of {Math.ceil(phoneData.total / limit)}
                    </span>
                    <button
                      onClick={() => setPage(p => p + 1)}
                      disabled={page >= Math.ceil(phoneData.total / limit)}
                      className="p-2 border border-border rounded-sm hover:bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </>
            )}
          </main>
        </div>
      </div>

      {/* Mobile filter backdrop */}
      {showMobileFilters && (
        <div className="fixed inset-0 z-40 bg-background/60 md:hidden" onClick={() => setShowMobileFilters(false)} />
      )}
    </Layout>
  );
}

function ActiveChip({ label, onRemove }: { label: string; onRemove: () => void }) {
  return (
    <span className="flex items-center gap-1.5 bg-primary/10 text-primary border border-primary/30 rounded-full px-3 py-1 text-xs font-mono">
      {label}
      <button onClick={onRemove} className="hover:text-primary/60">
        <X className="w-3 h-3" />
      </button>
    </span>
  );
}
