import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'wouter';
import { Smartphone, Search, Menu, X, BarChart3, Scale, Layers } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useListPhones } from '@workspace/api-client-react';

function GlobalSearch() {
  const [, setLocation] = useLocation();
  const [query, setQuery] = useState('');
  const [debounced, setDebounced] = useState('');
  const [open, setOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(query), 150);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const { data, isFetching } = useListPhones(
    { search: debounced, limit: 6 },
    { query: { enabled: debounced.length >= 1 } }
  );

  const results = data?.phones ?? [];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      setLocation(`/catalog?search=${encodeURIComponent(query.trim())}`);
      setOpen(false);
      setQuery('');
      inputRef.current?.blur();
    }
  };

  const handleSelect = (id: number) => {
    setLocation(`/phone/${id}`);
    setOpen(false);
    setQuery('');
  };

  return (
    <div ref={containerRef} className="relative w-72">
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          {isFetching && debounced && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 border-2 border-primary/40 border-t-primary rounded-full animate-spin" />
          )}
          <input
            ref={inputRef}
            type="text"
            placeholder="Search phones..."
            value={query}
            onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
            onFocus={() => query && setOpen(true)}
            className="w-full bg-secondary border border-border rounded-full py-1.5 pl-9 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-primary transition-all"
          />
        </div>
      </form>

      <AnimatePresence>
        {open && debounced && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.12 }}
            className="absolute top-full mt-2 left-0 right-0 bg-card border border-border rounded-xl shadow-2xl overflow-hidden z-[100]"
          >
            {results.length === 0 && !isFetching ? (
              <div className="px-4 py-6 text-center text-sm text-muted-foreground font-mono">
                No results for "{debounced}"
              </div>
            ) : (
              <div className="divide-y divide-border/50">
                {results.map(phone => (
                  <button
                    key={phone.id}
                    type="button"
                    onClick={() => handleSelect(phone.id)}
                    className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-secondary transition-colors text-left"
                  >
                    <img
                      src={phone.imageUrl}
                      alt={phone.name}
                      className="w-8 h-10 object-contain flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-xs text-primary font-mono">{phone.brand}</div>
                      <div className="text-sm font-semibold truncate">{phone.name}</div>
                    </div>
                    <div className="text-xs font-mono text-muted-foreground flex-shrink-0">
                      {phone.priceUsd ? `$${phone.priceUsd}` : phone.launchYear}
                    </div>
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => {
                    setLocation(`/catalog?search=${encodeURIComponent(debounced)}`);
                    setOpen(false);
                    setQuery('');
                  }}
                  className="w-full px-4 py-2.5 text-xs text-primary font-mono hover:bg-primary/10 transition-colors text-center flex items-center justify-center gap-2"
                >
                  <Search className="w-3 h-3" />
                  See all results for "{debounced}"
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [mobileQuery, setMobileQuery] = useState('');

  const handleMobileSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (mobileQuery.trim()) {
      setLocation(`/catalog?search=${encodeURIComponent(mobileQuery)}`);
      setIsMobileMenuOpen(false);
      setMobileQuery('');
    }
  };

  const navLinks = [
    { href: '/catalog', label: 'Catalog', icon: Layers },
    { href: '/compare', label: 'Compare', icon: Scale },
    { href: '/analytics', label: 'Analytics', icon: BarChart3 },
  ];

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background text-foreground dark">
      <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 text-primary hover:text-primary/80 transition-colors">
            <Smartphone className="w-6 h-6" />
            <span className="font-bold text-xl tracking-tight uppercase">PHONE HUB</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <nav className="flex items-center gap-6">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors ${
                    location === link.href ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <link.icon className="w-4 h-4" />
                  {link.label}
                </Link>
              ))}
            </nav>
            <GlobalSearch />
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden text-foreground"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden border-b border-border bg-background overflow-hidden"
            >
              <div className="p-4 flex flex-col gap-4">
                <form onSubmit={handleMobileSearch} className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <input
                    type="text"
                    placeholder="Search phones..."
                    value={mobileQuery}
                    onChange={(e) => setMobileQuery(e.target.value)}
                    className="w-full bg-secondary border border-border rounded-full py-2 pl-9 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </form>
                <nav className="flex flex-col gap-2">
                  {navLinks.map((link) => (
                    <Link
                      key={link.href}
                      href={link.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={`flex items-center gap-3 p-2 rounded-md ${
                        location === link.href ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-secondary'
                      }`}
                    >
                      <link.icon className="w-5 h-5" />
                      {link.label}
                    </Link>
                  ))}
                </nav>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main className="flex-1">
        {children}
      </main>

      <footer className="border-t border-border py-8 mt-12 bg-card">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 text-muted-foreground text-sm">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-primary" />
            <span className="font-bold text-foreground">PHONE HUB</span>
          </div>
          <p>© {new Date().getFullYear()} Phone Hub. All systems nominal.</p>
        </div>
      </footer>
    </div>
  );
}
