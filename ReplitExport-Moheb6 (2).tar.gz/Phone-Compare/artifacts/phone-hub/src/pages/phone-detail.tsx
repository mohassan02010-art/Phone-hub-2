import React, { useState } from 'react';
import { Layout } from '@/components/layout';
import { PhoneCard } from '@/components/phone-card';
import { SkeletonDetailHero } from '@/components/skeleton';
import { useParams } from 'wouter';
import { useGetPhone, useGetSimilarPhones } from '@workspace/api-client-react';
import { getGetPhoneQueryKey } from '@workspace/api-client-react';
import { motion } from 'framer-motion';
import {
  Smartphone, Cpu, Camera, BatteryFull, MonitorSmartphone,
  ChevronLeft, Scale, Check, X, Star, ArrowRight,
  Wifi, Bluetooth, Usb, Nfc, Zap
} from 'lucide-react';
import { Link } from 'wouter';

const TABS = ['Overview', 'Display', 'Performance', 'Camera', 'Battery', 'Connectivity'] as const;
type Tab = typeof TABS[number];

export default function PhoneDetail() {
  const { id } = useParams();
  const phoneId = parseInt(id || '0');
  const [imgError, setImgError] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>('Overview');

  const { data: phone, isLoading, error } = useGetPhone(phoneId, {
    query: { enabled: !!phoneId, queryKey: getGetPhoneQueryKey(phoneId) }
  });

  const { data: similar } = useGetSimilarPhones(phoneId, 6, {
    query: { enabled: !!phoneId }
  });

  if (isLoading) {
    return (
      <Layout>
        <SkeletonDetailHero />
      </Layout>
    );
  }

  if (error || !phone) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-32 text-center">
          <Smartphone className="w-16 h-16 text-muted-foreground/20 mx-auto mb-6" />
          <h1 className="text-3xl font-bold mb-3">Device Not Found</h1>
          <p className="text-muted-foreground mb-8 font-mono text-sm">The requested record does not exist in the database.</p>
          <Link href="/catalog" className="inline-flex items-center gap-2 text-primary hover:underline font-mono text-sm">
            <ChevronLeft className="w-4 h-4" /> Return to Catalog
          </Link>
        </div>
      </Layout>
    );
  }

  const hasCamera = phone.mainCameraMp || phone.frontCameraMp || phone.ultrawideCameraMp || phone.telephotoMp;
  const hasDisplay = phone.displayType || phone.displaySize || phone.displayResolution || phone.displayRefreshRate;
  const hasPerformance = phone.processor || phone.os || phone.ram || phone.storage;
  const hasBattery = phone.batteryMah || phone.chargingWatts;
  const hasConnectivity = phone.has5g !== null || phone.hasNfc !== null || phone.wifi || phone.bluetooth;

  return (
    <Layout>
      {/* Breadcrumb */}
      <div className="border-b border-border/50 bg-card/20">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-mono text-muted-foreground">
            <Link href="/catalog" className="hover:text-primary transition-colors flex items-center gap-1">
              <ChevronLeft className="w-3.5 h-3.5" /> Catalog
            </Link>
            <span>/</span>
            <span className="text-primary">{phone.brand}</span>
            <span>/</span>
            <span className="text-foreground truncate max-w-48">{phone.name}</span>
          </div>
          <Link
            href={`/compare?ids=${phone.id}`}
            className="hidden sm:flex items-center gap-1.5 text-xs font-bold font-mono tracking-widest text-primary border border-primary/30 px-3 py-1.5 rounded-lg hover:bg-primary/10 transition-colors"
          >
            <Scale className="w-3.5 h-3.5" /> Compare
          </Link>
        </div>
      </div>

      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <div className="relative overflow-hidden bg-gradient-to-b from-card/60 to-background border-b border-border">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_80%_at_70%_50%,rgba(0,212,255,0.06),transparent)] pointer-events-none" />
        <div className="container mx-auto px-4 py-16">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left: Info */}
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/10 border border-primary/20 rounded-full text-primary font-mono text-xs uppercase tracking-widest mb-4">
                {phone.brand}
              </div>
              <h1 className="text-4xl md:text-6xl font-black tracking-tight mb-2 text-foreground leading-none">
                {phone.name}
              </h1>
              {phone.model && phone.model !== phone.name && (
                <p className="text-muted-foreground font-mono text-sm mb-6">{phone.model}</p>
              )}

              {/* Price + Rating row */}
              <div className="flex items-center gap-6 mb-8">
                {phone.priceUsd ? (
                  <div>
                    <div className="text-4xl font-black text-primary font-mono">${phone.priceUsd}</div>
                    <div className="text-xs text-muted-foreground font-mono">Launch Price</div>
                  </div>
                ) : (
                  <div className="text-2xl font-bold text-muted-foreground font-mono">TBA</div>
                )}
                {phone.rating && (
                  <div className="flex items-center gap-2 bg-yellow-500/10 border border-yellow-500/20 px-4 py-2 rounded-xl">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <div>
                      <div className="font-bold text-xl text-yellow-400 font-mono">{phone.rating.toFixed(1)}</div>
                      <div className="text-[10px] text-muted-foreground font-mono">/ 10 Rating</div>
                    </div>
                  </div>
                )}
              </div>

              {/* Key badges */}
              <div className="flex flex-wrap gap-2 mb-8">
                {phone.launchDate && (
                  <span className="text-xs font-mono px-3 py-1.5 bg-secondary border border-border rounded-lg text-muted-foreground">
                    📅 {phone.launchDate}
                  </span>
                )}
                {phone.has5g && (
                  <span className="text-xs font-mono px-3 py-1.5 bg-primary/10 border border-primary/30 rounded-lg text-primary font-bold">
                    5G
                  </span>
                )}
                {phone.hasNfc && (
                  <span className="text-xs font-mono px-3 py-1.5 bg-secondary border border-border rounded-lg">NFC</span>
                )}
                {phone.hasWirelessCharging && (
                  <span className="text-xs font-mono px-3 py-1.5 bg-secondary border border-border rounded-lg">Wireless Charging</span>
                )}
                {phone.displayRefreshRate && (
                  <span className="text-xs font-mono px-3 py-1.5 bg-secondary border border-border rounded-lg">{phone.displayRefreshRate}Hz</span>
                )}
                {phone.os && (
                  <span className="text-xs font-mono px-3 py-1.5 bg-secondary border border-border rounded-lg">{phone.os}</span>
                )}
              </div>

              <div className="flex gap-3">
                <Link href={`/compare?ids=${phone.id}`}
                  className="flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-xl font-bold hover:bg-primary/90 hover:shadow-[0_0_20px_rgba(0,212,255,0.3)] transition-all">
                  <Scale className="w-4 h-4" /> Compare Device
                </Link>
                <Link href="/catalog"
                  className="flex items-center gap-2 bg-secondary border border-border text-foreground px-6 py-3 rounded-xl font-semibold hover:border-primary/40 transition-all">
                  Browse More
                </Link>
              </div>
            </motion.div>

            {/* Right: Image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="relative flex items-center justify-center"
            >
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,212,255,0.08),transparent_60%)] rounded-3xl" />
              <div className="relative bg-gradient-to-b from-white/[0.04] to-transparent rounded-3xl border border-border/50 p-12 w-full flex items-center justify-center min-h-[400px]">
                {!imgError ? (
                  <img
                    src={phone.imageUrl}
                    alt={phone.name}
                    className="max-h-[380px] max-w-full object-contain drop-shadow-[0_30px_60px_rgba(0,0,0,0.7)]"
                    onError={() => setImgError(true)}
                  />
                ) : (
                  <Smartphone className="w-32 h-32 text-muted-foreground/20" />
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* ── KEY SPECS ────────────────────────────────────────────────── */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <KeySpec icon={Smartphone} label="Display" value={phone.displaySize ? `${phone.displaySize}"` : '—'} sub={phone.displayType ?? ''} />
          <KeySpec icon={Cpu} label="Processor" value={phone.processor?.split(' ')[0] ?? '—'} sub={phone.processor?.split(' ').slice(1).join(' ') ?? ''} />
          <KeySpec icon={Camera} label="Main Camera" value={phone.mainCameraMp ? `${phone.mainCameraMp}MP` : '—'} sub={phone.videoResolution ?? ''} />
          <KeySpec icon={Battery} label="Battery" value={phone.batteryMah ? `${phone.batteryMah}mAh` : '—'} sub={phone.chargingWatts ? `${phone.chargingWatts}W Fast Charge` : ''} />
        </div>

        {/* ── TABS ───────────────────────────────────────────────────── */}
        <div className="flex gap-1 p-1 bg-card border border-border rounded-xl w-full overflow-x-auto mb-8">
          {TABS.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-shrink-0 px-4 py-2 rounded-lg text-sm font-semibold transition-all whitespace-nowrap ${
                activeTab === tab
                  ? 'bg-primary text-primary-foreground shadow-[0_0_12px_rgba(0,212,255,0.25)]'
                  : 'text-muted-foreground hover:text-foreground hover:bg-secondary/60'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="min-h-[300px]">
          {activeTab === 'Overview' && (
            <div className="grid md:grid-cols-2 gap-6">
              <SpecCard title="Design & Build">
                <SpecLine label="Weight" value={phone.weight ? `${phone.weight}g` : null} />
                <SpecLine label="Thickness" value={phone.thickness ? `${phone.thickness}mm` : null} />
                <SpecLine label="Colors" value={phone.colors} />
                <SpecLine label="SIM" value={phone.simType} />
              </SpecCard>
              <SpecCard title="Quick Specs">
                <SpecLine label="OS" value={phone.os} />
                <SpecLine label="Display" value={phone.displaySize ? `${phone.displaySize}" ${phone.displayType ?? ''}`.trim() : null} />
                <SpecLine label="RAM" value={phone.ramOptions || (phone.ram ? `${phone.ram}GB` : null)} />
                <SpecLine label="Storage" value={phone.storageOptions || (phone.storage ? `${phone.storage}GB` : null)} />
                <SpecLine label="Main Camera" value={phone.mainCameraMp ? `${phone.mainCameraMp}MP` : null} />
                <SpecLine label="Battery" value={phone.batteryMah ? `${phone.batteryMah}mAh` : null} />
              </SpecCard>
              <SpecCard title="Connectivity">
                <BoolLine label="5G" value={phone.has5g} />
                <BoolLine label="NFC" value={phone.hasNfc} />
                <BoolLine label="Wireless Charging" value={phone.hasWirelessCharging} />
                <BoolLine label="Headphone Jack" value={phone.hasHeadphoneJack} />
              </SpecCard>
              <SpecCard title="Cameras">
                <SpecLine label="Main" value={phone.mainCameraMp ? `${phone.mainCameraMp}MP` : null} />
                <SpecLine label="Ultrawide" value={phone.ultrawideCameraMp ? `${phone.ultrawideCameraMp}MP` : null} />
                <SpecLine label="Telephoto" value={phone.telephotoMp ? `${phone.telephotoMp}MP` : null} />
                <SpecLine label="Selfie" value={phone.frontCameraMp ? `${phone.frontCameraMp}MP` : null} />
                <SpecLine label="Video" value={phone.videoResolution} />
              </SpecCard>
            </div>
          )}

          {activeTab === 'Display' && hasDisplay && (
            <SpecCard title="Display & Design" full>
              <SpecLine label="Panel Type" value={phone.displayType} />
              <SpecLine label="Size" value={phone.displaySize ? `${phone.displaySize} inches` : null} />
              <SpecLine label="Resolution" value={phone.displayResolution} />
              <SpecLine label="Refresh Rate" value={phone.displayRefreshRate ? `${phone.displayRefreshRate}Hz` : null} />
              <SpecLine label="Peak Brightness" value={phone.displayNits ? `${phone.displayNits} nits` : null} />
              <SpecLine label="Thickness" value={phone.thickness ? `${phone.thickness}mm` : null} />
              <SpecLine label="Weight" value={phone.weight ? `${phone.weight}g` : null} />
              <SpecLine label="Colors" value={phone.colors} />
            </SpecCard>
          )}

          {activeTab === 'Performance' && hasPerformance && (
            <SpecCard title="Platform & Memory" full>
              <SpecLine label="Operating System" value={phone.os} />
              <SpecLine label="Chipset" value={phone.processor} />
              <SpecLine label="Process Node" value={phone.processorNm ? `${phone.processorNm}nm` : null} />
              <SpecLine label="RAM Options" value={phone.ramOptions || (phone.ram ? `${phone.ram}GB` : null)} />
              <SpecLine label="Storage Options" value={phone.storageOptions || (phone.storage ? `${phone.storage}GB` : null)} />
            </SpecCard>
          )}

          {activeTab === 'Camera' && hasCamera && (
            <SpecCard title="Camera System" full>
              <SpecLine label="Main Camera" value={phone.mainCameraMp ? `${phone.mainCameraMp}MP wide` : null} />
              <SpecLine label="Ultrawide" value={phone.ultrawideCameraMp ? `${phone.ultrawideCameraMp}MP ultrawide` : null} />
              <SpecLine label="Telephoto" value={phone.telephotoMp ? `${phone.telephotoMp}MP telephoto` : null} />
              <SpecLine label="Selfie" value={phone.frontCameraMp ? `${phone.frontCameraMp}MP front` : null} />
              <SpecLine label="Video Recording" value={phone.videoResolution} />
            </SpecCard>
          )}

          {activeTab === 'Battery' && hasBattery && (
            <SpecCard title="Battery & Charging" full>
              <SpecLine label="Capacity" value={phone.batteryMah ? `${phone.batteryMah}mAh` : null} />
              <SpecLine label="Fast Charging" value={phone.chargingWatts ? `${phone.chargingWatts}W` : null} />
              <BoolLine label="Wireless Charging" value={phone.hasWirelessCharging} />
            </SpecCard>
          )}

          {activeTab === 'Connectivity' && hasConnectivity && (
            <SpecCard title="Connectivity" full>
              <BoolLine label="5G Network" value={phone.has5g} />
              <BoolLine label="NFC" value={phone.hasNfc} />
              <BoolLine label="Wireless Charging" value={phone.hasWirelessCharging} />
              <BoolLine label="Headphone Jack" value={phone.hasHeadphoneJack} />
              <SpecLine label="Wi-Fi" value={phone.wifi} />
              <SpecLine label="Bluetooth" value={phone.bluetooth} />
              <SpecLine label="USB" value={phone.usb} />
              <SpecLine label="SIM Type" value={phone.simType} />
            </SpecCard>
          )}
        </div>

        {/* ── SIMILAR PHONES ───────────────────────────────────────── */}
        {similar && similar.length > 0 && (
          <div className="mt-20 pt-16 border-t border-border">
            <div className="flex items-center justify-between mb-8">
              <div>
                <p className="text-xs font-mono text-muted-foreground uppercase tracking-widest mb-1">From {phone.brand}</p>
                <h2 className="text-2xl font-black tracking-tight">Similar Devices</h2>
              </div>
              <Link href={`/catalog?brand=${encodeURIComponent(phone.brand)}`}
                className="flex items-center gap-1.5 text-primary font-mono text-xs uppercase tracking-widest hover:text-primary/80 transition-colors group">
                All {phone.brand}
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </Link>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              {similar.slice(0, 6).map((p, i) => (
                <PhoneCard key={p.id} phone={p} index={i} variant="default" />
              ))}
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}

/* ── Sub-components ──────────────────────────────────────────────────── */

function KeySpec({ icon: Icon, label, value, sub }: { icon: any; label: string; value: string; sub: string }) {
  return (
    <div className="bg-card border border-border rounded-2xl p-5 hover:border-primary/30 transition-colors">
      <div className="flex items-center gap-2 mb-3">
        <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
          <Icon className="w-4 h-4 text-primary" />
        </div>
        <span className="text-xs font-mono text-muted-foreground uppercase tracking-widest">{label}</span>
      </div>
      <div className="font-bold text-xl text-foreground leading-tight">{value}</div>
      {sub && <div className="text-xs text-muted-foreground mt-1 truncate">{sub}</div>}
    </div>
  );
}

function SpecCard({ title, children, full }: { title: string; children: React.ReactNode; full?: boolean }) {
  const items = React.Children.toArray(children).filter(Boolean);
  if (items.length === 0) return null;
  return (
    <div className={`bg-card border border-border rounded-2xl overflow-hidden ${full ? 'md:col-span-2' : ''}`}>
      <div className="px-6 py-4 border-b border-border bg-secondary/30">
        <h3 className="font-bold text-sm uppercase tracking-widest text-primary">{title}</h3>
      </div>
      <div className="divide-y divide-border/50">{children}</div>
    </div>
  );
}

function SpecLine({ label, value }: { label: string; value: string | number | null | undefined }) {
  if (value === null || value === undefined || value === '') return null;
  return (
    <div className="flex items-center py-3 px-6 hover:bg-white/[0.02] transition-colors">
      <div className="w-1/3 text-sm text-muted-foreground font-medium">{label}</div>
      <div className="w-2/3 text-sm font-medium text-foreground">{value}</div>
    </div>
  );
}

function BoolLine({ label, value }: { label: string; value: boolean | null | undefined }) {
  if (value === null || value === undefined) return null;
  return (
    <div className="flex items-center py-3 px-6 hover:bg-white/[0.02] transition-colors">
      <div className="w-1/3 text-sm text-muted-foreground font-medium">{label}</div>
      <div className="w-2/3 flex items-center gap-2">
        {value ? (
          <span className="flex items-center gap-1.5 text-primary text-sm font-medium">
            <Check className="w-4 h-4" /> Supported
          </span>
        ) : (
          <span className="flex items-center gap-1.5 text-muted-foreground/50 text-sm">
            <X className="w-4 h-4" /> Not Available
          </span>
        )}
      </div>
    </div>
  );
}
